package dummy;


import com.google.code.geocoder.Geocoder;
import com.google.code.geocoder.GeocoderRequestBuilder;
import com.google.code.geocoder.model.*;
import com.google.gson.Gson;
import com.hp.hpl.jena.rdf.model.ModelFactoryBase;
import com.hp.hpl.jena.sparql.lang.SPARQLParser;
//import com.tenforce.semtech.SPARQLParser.SPARQL.InvalidSPARQLException;
//import com.tenforce.semtech.SPARQLParser.SPARQL.SPARQLQuery;
import org.apache.commons.httpclient.util.URIUtil;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.entity.BasicHttpEntity;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.InputStreamEntity;
import org.eclipse.rdf4j.IsolationLevels;
import org.eclipse.rdf4j.model.*;
import org.eclipse.rdf4j.model.impl.LinkedHashModel;
import org.eclipse.rdf4j.model.impl.SimpleBNode;
import org.eclipse.rdf4j.model.impl.SimpleNamespace;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import org.eclipse.rdf4j.model.util.ModelBuilder;
import org.eclipse.rdf4j.model.util.RDFCollections;
import org.eclipse.rdf4j.model.vocabulary.FOAF;
import org.eclipse.rdf4j.model.vocabulary.RDF;
import org.eclipse.rdf4j.model.vocabulary.RDFS;
/*import org.eclipse.rdf4j.query.Query;
import org.eclipse.rdf4j.query.QueryLanguage;
import org.eclipse.rdf4j.query.TupleQueryResult;
import org.eclipse.rdf4j.query.algebra.Datatype;
import org.eclipse.rdf4j.query.algebra.QueryModelVisitor;
import org.eclipse.rdf4j.query.algebra.TupleExpr;
import org.eclipse.rdf4j.query.algebra.helpers.QueryModelVisitorBase;
import org.eclipse.rdf4j.query.parser.ParsedOperation;
import org.eclipse.rdf4j.query.parser.ParsedQuery;
import org.eclipse.rdf4j.query.parser.QueryParser;
import org.eclipse.rdf4j.query.parser.QueryParserUtil;
import org.eclipse.rdf4j.query.parser.sparql.SPARQLParser;
import org.eclipse.rdf4j.query.parser.sparql.SPARQLParserFactory;
import org.eclipse.rdf4j.query.parser.sparql.SPARQLUtil;
import org.eclipse.rdf4j.repository.Repository;
import org.eclipse.rdf4j.repository.RepositoryConnection;
import org.eclipse.rdf4j.repository.RepositoryResult;
import org.eclipse.rdf4j.repository.http.HTTPRepository;
import org.eclipse.rdf4j.repository.manager.RemoteRepositoryManager;
import org.eclipse.rdf4j.repository.manager.RepositoryManager;
import org.eclipse.rdf4j.repository.sparql.SPARQLConnection;*/
import org.eclipse.rdf4j.rio.*;
import org.eclipse.rdf4j.rio.helpers.JSONLDMode;
import org.eclipse.rdf4j.rio.helpers.JSONLDSettings;
import org.eclipse.rdf4j.rio.helpers.RDFJSONParserSettings;
import org.eclipse.rdf4j.rio.helpers.RioSettingImpl;
import org.eclipse.rdf4j.rio.jsonld.JSONLDParser;
import org.eclipse.rdf4j.rio.jsonld.JSONLDWriter;
import org.eclipse.rdf4j.rio.jsonld.JSONLDWriterFactory;
//import org.eclipse.rdf4j.rio.turtle.TurtleParser;
import org.eclipse.rdf4j.sparqlbuilder.core.Prefix;
import org.eclipse.rdf4j.sparqlbuilder.core.Variable;
import org.eclipse.rdf4j.sparqlbuilder.core.query.ConstructQuery;
import org.eclipse.rdf4j.sparqlbuilder.core.query.Queries;
import org.eclipse.rdf4j.sparqlbuilder.core.query.SelectQuery;
import org.eclipse.rdf4j.sparqlbuilder.graphpattern.TriplePattern;
import org.xenei.jena.entities.EntityManager;
import org.xenei.jena.entities.EntityManagerFactory;
import org.xenei.jena.entities.MissingAnnotation;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test {
    public static void main(String[] args){
        String s = "<http://localhost:8060/ajan/agents/majanAgent1> <http://www.ajan.de/ajan-ns#agentId>\n" +
"    \"majanAgent1\";\n" +
"  <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#hasGender>\n" +
"    \"Male\";\n" +
"  <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#hasLccGenderPreference>\n" +
"    \"Dont mind\";\n" +
"  <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#hasLccNationPreference>\n" +
"    \"Same\";\n" +
"  <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#hasNationality>\n" +
"    \"Nation1\" .\n" +
"\n" +
"<https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#1638966802499>\n" +
"  a <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#LCCLesson>;\n" +
"  <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#hasAssessmentScore>\n" +
"    \"26\"^^<http://www.w3.org/2001/XMLSchema#float>;\n" +
"  <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#hasLessonId>\n" +
"    1;\n" +
"  <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#hasListeningScore>\n" +
"    \"9\"^^<http://www.w3.org/2001/XMLSchema#float>;\n" +
"  <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#hasReadingScore>\n" +
"    \"10\"^^<http://www.w3.org/2001/XMLSchema#float>;\n" +
"  <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#hasVocabularyScore>\n" +
"    \"11\"^^<http://www.w3.org/2001/XMLSchema#float>;\n" +
"  <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#hasWritingScore>\n" +
"    \"12\"^^<http://www.w3.org/2001/XMLSchema#float> .";
        
        String query = "\n" +
"					PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> \n" +
"					PREFIX ajan: <http://www.ajan.de/ajan-ns#>\n" +
"					PREFIX welcome: <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#>\n" +
"					PREFIX mac: <http://localhost:8090/rdf4j/repositories/ajan_mac_ontology#>\n" +
"					PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n" +
"					CONSTRUCT {\n" +
"						?subjectIri    rdf:type    welcome:LCCLesson ;\n" +
"											welcome:hasLessonId		?lessonId ;\n" +
"											welcome:hasAssessmentDeadline     ?assessmentDeadline .\n" +
"					}\n" +
"					WHERE {\n" +
"						?subjectIri    rdf:type    welcome:LCCLesson ;\n" +
"											welcome:hasLessonId		?lessonId ;\n" +
"											welcome:hasAssessmentDeadline     ?assessmentDeadline .	\n" +
"					}";
        

        /*try {
            Model model = createModel(s);
            model = addNamespacesFromSparql(model, query);
            for(Namespace nms:model.getNamespaces()){
                System.out.println("nms:"+nms);
            }
        } catch (IOException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }*/
           runJarFile();
        
        
    }
    
    public static void runJarFile(){
        String command = "java -jar C:\\Users\\akka02\\Desktop\\BOSS_Central.jar";
        String cmd = "java -jar \"C:\\Users\\akka02\\Desktop\\Thesis (github)\\Software\\EclipseWorkspace\\Baseline Solution\\BOSS_for_baseline\\BOSS algorithm\\BOSS_Central.jar\"";
        try {
//java -jar "C:\\Users\akka02\Desktop\Thesis (github)\Software\EclipseWorkspace\Baseline Solution\BOSS_for_baseline\BOSS algorithm\BOSS_Central.jar"
            Process pr =  Runtime.getRuntime().exec(cmd);
            InputStream in = pr.getInputStream();
            InputStream errs = pr.getErrorStream();
            OutputStream out = pr.getOutputStream();
            
            StringBuilder error = new StringBuilder();
            try (Reader reader = new BufferedReader(new InputStreamReader(errs, Charset.forName(StandardCharsets.UTF_8.name())))) {
                int c = 0;
                while ((c = reader.read()) != -1) {
                    error.append((char) c);
                }
            }
            
            System.out.println("error:"+error.toString());
            StringBuilder output = new StringBuilder();
            try (Reader reader = new BufferedReader(new InputStreamReader(in, Charset.forName(StandardCharsets.UTF_8.name())))) {
                int c = 0;
                while ((c = reader.read()) != -1) {
                    output.append((char) c);
                }
            }
            
            System.out.println("output:"+output.toString());
            System.out.println("11:"+pr.isAlive());
            /*
            Scanner scan = new Scanner(System.in);
            BufferedReader reader = new BufferedReader (new InputStreamReader(in));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            String input = scan.nextLine();
            input += "\n";
            writer.write(input);
            writer.flush();
            input = scan.nextLine();
            input += "\n";
            writer.write(input);
            writer.flush();
            String line;
            while ((line = reader.readLine ()) != null) {
                System.out.println ("Stdout: " + line);
            }
            
            input = scan.nextLine();
            input += "\n";
            writer.write(input);
            writer.close();
            
            while ((line = reader.readLine ()) != null) {
                System.out.println ("Stdout: " + line);
            }*/
        } catch (IOException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static String execCmd(String cmd) {
        String result = null;
        try (InputStream inputStream = Runtime.getRuntime().exec(cmd).getInputStream();
                Scanner s = new Scanner(inputStream).useDelimiter("\\A")) {
            result = s.hasNext() ? s.next() : null;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }
        public static Model addNamespacesFromSparql(Model model, String sparqlQuery){
            int index = 0;
            if(sparqlQuery.contains("CONSTRUCT")){
                index = sparqlQuery.indexOf("CONSTRUCT");
            }else if(sparqlQuery.contains("ASK")){
                index = sparqlQuery.indexOf("ASK");
            }else if(sparqlQuery.contains("SELECT")){
                index = sparqlQuery.indexOf("SELECT");
            }else if(sparqlQuery.contains("INSERT")){
                index = sparqlQuery.indexOf("INSERT");
            }
            if(sparqlQuery.contains("DELETE")){
                index = sparqlQuery.indexOf("DELETE");
            }
            
            sparqlQuery = sparqlQuery.substring(0, index);
                System.out.println("0--"+sparqlQuery);

            //Set<Namespace> namespaces = new HashSet<>();
            while(sparqlQuery.contains("PREFIX")){
                int prfIndex = sparqlQuery.indexOf("PREFIX") ;
                int symbolIndex = sparqlQuery.indexOf(">");
                String sub = sparqlQuery.substring(prfIndex+6, symbolIndex);
                String[] spt = sub.split("<");
                String prefix = spt[0].trim().replace(":", "");
                String url = spt[1].trim();
                sparqlQuery = sparqlQuery.substring(0, prfIndex) + sparqlQuery.substring(symbolIndex+1, sparqlQuery.length()).trim();
                model.setNamespace(prefix, url);
                System.out.println("1--"+prfIndex);
                System.out.println("2--"+symbolIndex);
                System.out.println("3--"+sub);
                System.out.println("4--"+spt[0]);
                System.out.println("5--"+spt[1]);
                System.out.println("6--"+sparqlQuery);
            }
              /*int prfIndex = sparqlQuery.indexOf("PREFIX") ;
            int symbolIndex = sparqlQuery.indexOf(">");
            String sub = sparqlQuery.substring(prfIndex+6, symbolIndex);
            String[] spt = sub.split("<");
            String prefix = spt[0].trim().replace(":", "");
            String url = spt[1].trim();
            sparqlQuery = sparqlQuery.substring(0, prfIndex) + sparqlQuery.substring(symbolIndex+1, sparqlQuery.length()).trim();
              */    
            
            
            
            return model;
        }
        
    private static Model readRequest(String request, RDFFormat format) throws IOException {
//        System.out.println("Request:");
//        System.out.println(request);
        InputStream input = new ByteArrayInputStream(request.getBytes());
        RDFFormat f = Rio.getParserFormatForFileName(request).orElse(format);
        System.out.println("--"+f);
        RDFParser rp = Rio.createParser(format);
        rp.parse(input);
        
        Model model = Rio.parse(input, "", format);
        
        for (Statement statement : model) {
            System.out.println(statement);
        }
        return model;
    }
    private static Model createModel(String in) throws IOException{
        InputStream inputStream = new ByteArrayInputStream(in.getBytes());


        Model model = Rio.parse(inputStream, "", RDFFormat.TURTLE);
        return model;
    }
    /*
    public static String trigINP = "@prefix : <http://localhost:8080/WelcomeServiceDescriptions/CatalanReceptionService.owls> .\n" +
            "@prefix process: <http://www.daml.org/services/owl-s/1.1/Process.owl#> .\n" +
            "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n" +
            "@prefix owl: <http://www.w3.org/2002/07/owl#> .\n" +
            "@prefix service: <http://www.daml.org/services/owl-s/1.1/Service.owl#> .\n" +
            "@prefix profile: <http://www.daml.org/services/owl-s/1.1/Profile.owl#> .\n" +
            "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .\n" +
            "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\n" +
            "@prefix welcome: <http://localhost:8080/WelcomeServiceDescriptions/Welcome.owl#> .\n" +
            "@prefix pddlexpr: <http://127.0.0.1:8080/ontology/PDDLExpression.owl#> .\n" +
            "@prefix expr: <http://www.daml.org/services/owl-s/1.1/generic/Expression.owl#> .\n" +
            "@prefix grounding: <http://www.daml.org/services/owl-s/1.1/Grounding.owl#> .\n" +
            "@prefix swrl: <http://www.w3.org/2003/11/swrl#> .\n" +
            "@prefix actor: <http://www.daml.org/services/owl-s/1.2/ActorDefault.owl#> .\n" +
            "@prefix objectList: <http://www.daml.org/services/owl-s/1.2/generic/ObjectList.owl#> .\n" +
            "@prefix swrl-onto: <http://www.daml.org/rules/proposal/swrl.owl> .\n" +
            "@prefix congo_process: <http://www.daml.org/services/owl-s/1.2/Process.owl#> .\n" +
            "@prefix congo_profile: <http://www.daml.org/services/owl-s/1.2/Profile.owl#> .\n" +
            "@prefix congo_grounding: <http://www.daml.org/services/owl-s/1.2/Grounding.owl#> .\n" +
            "@prefix objList: <http://localhost:8080/ontology/ObjectList.owl> .\n" +
            "\n" +
            "<http://localhost:8080/WelcomeServicesOffers/FirstReceptionService> {\n" +
            "\t<http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl> a owl:Ontology ;\n" +
            "\t\trdfs:comment \"Semantic Service Description First Reception Service in Catalonia\" ;\n" +
            "\t\towl:imports <http://localhost:8080/WelcomeServiceDescriptions/Welcome.owl> , <http://localhost:8080/ontology/Process.owl> , <http://localhost:8080/ontology/Profile.owl> , <http://localhost:8080/ontology/Service.owl> , <http://localhost:8080/ontology/PDDLExpression.owl> .\n" +
            "\t\n" +
            "\t<http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#FirstReceptionService> a <http://localhost:8080/ontology/Service.owl#Service> ;\n" +
            "\t\t<http://localhost:8080/ontology/Service.owl#describedBy> <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#FillFormComposite> ;\n" +
            "\t\t<http://localhost:8080/ontology/Service.owl#presents> <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#FirstReceptionServiceProfile> .\n" +
            "\t\n" +
            "\t<http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#FillFormComposite> a <http://localhost:8080/ontology/Process.owl#CompositeProcess> ;\n" +
            "\t\t<http://localhost:8080/ontology/Service.owl#describes> <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#FirstReceptionService> ;\n" +
            "\t\t<http://localhost:8080/ontology/Process.owl#hasPrecondition> <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#FirstReceptionCondition> ;\n" +
            "\t\t<http://localhost:8080/ontology/Process.owl#hasInput> <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainAsylumClaim> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainBirthday> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainBuildingName> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainBuildingType> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainCityOfBirth> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainCountryOfBirth> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainCourseInstitution> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainCourseName> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainCoursesCatalan> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainCoursesLabour> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainCoursesSociety> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainCoursesSpanish> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainDoorNumber> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainDuration> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainEMailNotifications> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainEmail> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainEntrance> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainFirstSurname> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainFloorNumber> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainGender> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainIDCountry> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainIDNumber> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainIDType> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainIlliteracy> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainInterestRegistration> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainKnowledgeCatalan> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainKnowledgeLabour> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainKnowledgeSociety> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainKnowledgeSpanish> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainLandline> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainLearningHandicap> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainMaritalStatus> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainMobilePhone> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainMunicipality> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainName> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainNationality> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainNotificationPreferences> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainPostCode> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainPreviousResidenceCatalonia> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainPreviousResidenceOther> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainPreviousResidenceSpain> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainProvince> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainRegistrationYear> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainSMSNotifications> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainSecondSurname> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainStreetName> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainStreetNumber> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainStreetType> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainYearArrival> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#ObtainYearCompletion> ;\n" +
            "\t\t<http://localhost:8080/ontology/Process.owl#hasOutput> <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformDetailsCompletion> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformDetailsLanguage> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformDetailsTime> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformDetailsValue> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformLabourModule> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformLabourModuleAddress> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformLabourModuleHours> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformLanguageModule> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformLanguageModuleAddress> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformLanguageModuleHours> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformOverview> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformSocietyModule> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformSocietyModuleAddress> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformSocietyModuleHours> , <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#InformTraining> ;\n" +
            "\t\t<http://localhost:8080/ontology/Process.owl#composedOf> _:node1et28i2fvx2 ;\n" +
            "\t\t<http://localhost:8080/ontology/Process.owl#hasResult> <http://localhost:8080/WelcomeServicesOffers/FirstReceptionService.owl#FirstReceptionServiceResult> .\n" +
            "\t}";

    public static void main(String[] args) throws IOException/*, InvalidSPARQLException*/ {
//        parse();
//        createModelFromRDF();
//        testRdfJson();
//        queryParse();
//        String address = "Berlin, Germany";
//        convertLocation2Coordinates(address);
//        geocoder();
//        OpenStreetMapUtils openStreetMapUtils = new OpenStreetMapUtils();
//        Map<String, Double> coordinates = openStreetMapUtils.getCoordinates(address);
//        if (coordinates.entrySet() != null) {
//            for (int i = 0; i < coordinates.entrySet().size(); i++) {
//                System.out.println("coordinates.entrySet().toArray()[i] = " + coordinates.entrySet().toArray()[i]);
//                System.out.println("coordinates.keySet().toArray()[i] = " + coordinates.keySet().toArray()[i]);
//            }
//        }
//        createModelFromZero();
//        convert2CollectionTest();
//        testingRegex();
//        testingBlankNode();
//        testingCreateLiteralWithXSDString();

//        generateModel();
//        castToModel();
//        createModelFromRDF();
//        sendPostRequest();
      /*  try {
            serializeFeedback();
        } catch (MissingAnnotation missingAnnotation) {
            missingAnnotation.printStackTrace();
        }

    }
/*
    private static void serializeFeedback() throws MissingAnnotation {
        com.hp.hpl.jena.rdf.model.Model model = com.hp.hpl.jena.rdf.model.ModelFactory.createDefaultModel();
        EntityManager entityManager = EntityManagerFactory.getEntityManager();
        com.hp.hpl.jena.rdf.model.Resource resource = model.createResource("http://example.com/feedback");
        Feedback feedback = entityManager.read(resource, Feedback.class);
        feedback.setAddress("Waldhausweg 17");
        feedback.setID(15);
        feedback.setName("MyFeedback");
        feedback.setUsername("Akbar");

        System.out.println(model.listStatements().toList());
    }

    private static void testingSPARQLBuilder() {
        SelectQuery selectQuery = Queries.SELECT();
        ConstructQuery constructQuery = Queries.CONSTRUCT();

        Prefix prefix = null;
        Variable product;
        TriplePattern personWroteBook, personAuthoredBook;

//        selectQuery.prefix(prefix).select(product).where(product.isA(prefix.iri("book")));

    }

    private static void testRdfJson() {
        String mimeType = "application/rdf+json";
        Optional<RDFFormat> fileFormatForMIMEType = RDFWriterRegistry
                .getInstance().getFileFormatForMIMEType(mimeType);

        System.out.println("fileFormatForMIMEType.get() = " + fileFormatForMIMEType.get());
        System.out.println("fileFormatForMIMEType.isPresent() = " + fileFormatForMIMEType.isPresent());
        if (!fileFormatForMIMEType.isPresent()) {
            throw new IllegalArgumentException("No format known for Mime type " + mimeType);
        }

//        Optional<RDFFormat> fileFormatMimeType = RDFWriterRegistry
//                .getInstance().getFileFormatForMIMEType("application/rdf+json");

//        System.out.println(fileFormatMimeType.isPresent());
//        System.out.println("fileFormatMimeType.get() = " + fileFormatMimeType.get());
    }

    private static void createModelFromRDF() throws IOException {
        String rdfInput = "@prefix welcome: <http://welcome/services/1.0/> .\n" +
                "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n" +
                "welcome:TCN_Location a welcome:Location ;\n" +
                "    welcome:latitude \"49.247765\";\n" +
                "    welcome:longitude \"7.023154\";\n" +
                "    welcome:address_name \"Saarbrucken\".\n" +
                "\n" +
                "\n" +
                "welcome:Office1 a welcome:Office;\n" +
                "    welcome:latitude \"53.540307\" ;\n" +
                "    welcome:longitude \"9.986572\";\n" +
                "    welcome:address_name \"Hamburg\".\n" +
                "\n" +
                "welcome:Office2 a welcome:Office; \n" +
                "    welcome:latitude \"48.864715\" ;\n" +
                "    welcome:longitude \"2.197266\";\n" +
                "    welcome:address_name \"Paris\".\n" +
                "\n" +
                "welcome:Office3 a welcome:Office; \n" +
                "    welcome:latitude \"51.124213\" ;\n" +
                "    welcome:longitude \"17.006836\";\n" +
                "    welcome:address_name \"Wroclaw\".\n" +
                "\n" +
                "welcome:Office4 a welcome:Office; \n" +
                "    welcome:latitude \"51.508742\" ;\n" +
                "    welcome:longitude \"-0.219727\";\n" +
                "    welcome:address_name \"London\".\n" +
                "\n" +
                "welcome:Office5 a welcome:Office; \n" +
                "    welcome:latitude \"41.376809\" ;\n" +
                "    welcome:longitude \"2.131348\";\n" +
                "    welcome:address_name \"Barcelona\".\n" +
                "\n" +
                "welcome:Office6 a welcome:Office; \n" +
                "    welcome:latitude \"49.446700\" ;\n" +
                "    welcome:longitude \"7.767334\";\n" +
                "    welcome:address_name \"Kaiserslautern\".\n" +
                "\n" +
                "welcome:Office7 a welcome:Office;\n" +
                "    welcome:latitude \"48.122101\" ;\n" +
                "    welcome:longitude \"11.612549\";\n" +
                "    welcome:address_name \"Munchen\".";
        InputStream inputStream = new ByteArrayInputStream(rdfInput.getBytes());


        Model model = Rio.parse(inputStream, "", RDFFormat.TURTLE);

        printModel(model);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        RDFWriter writer = Rio.createWriter(RDFFormat.JSONLD, outputStream);
//                .set(JSONLDSettings.USE_NATIVE_TYPES, true);

//        Rio.write(model,outputStream,RDFFormat.RDFJSON);
//        JSONLDWriter jsonldWriter= (JSONLDWriter) Rio.createWriter(RDFFormat.JSONLD,outputStream);
        JSONLDWriter jsonldWriter1 = new JSONLDWriter(outputStream);


        try {
            jsonldWriter1.startRDF();
            for (Statement s : model) {
                jsonldWriter1.handleStatement(s);
            }
            jsonldWriter1.endRDF();
        } catch (RDFHandlerException e) {
            e.printStackTrace();
        } finally {
            outputStream.close();
        }


//        Rio.write(model, writer);

        System.out.println("Gelllllllllllllllllllllllllllllllllll");
//        System.out.println(outputStream.toString());
        System.out.println(new String(outputStream.toByteArray()));
        System.out.println("Getttttttttttttttttttttttttttttttt");

//        System.out.println("statements below:");
        Iterator<Statement> statementIterator = model.iterator();
        while (statementIterator.hasNext()) {
            System.out.println(statementIterator.next());

        }


        ValueFactory factory = SimpleValueFactory.getInstance();
        List<Model> officeModels = new ArrayList<>();
        Resource tcnLocationResource = factory.createIRI("http://welcome/services/1.0/TCN_Location");
        Resource officeResource = factory.createIRI("http://welcome/services/1.0/Office");

        Model tcnModel = model.filter(tcnLocationResource, null, null);
        Set<Resource> subjects = model.filter(null, null, officeResource).subjects();
        for (Resource subjectResource : subjects) {
            officeModels.add(model.filter(subjectResource, null, null));
        }


        Model closestModel = calcualteClosest(tcnModel, officeModels);
//
        Statement closestOfficeStatement = factory.createStatement(tcnModel.subjects().iterator().next(),
                factory.createIRI("http://welcome/services/1.0/closest"),
                closestModel.subjects().iterator().next());
        model.add(closestOfficeStatement);

//        System.out.println("Closest Office below:");
//        printModel(closestModel);
//        System.out.println("Full Model below:");
        printModel(model);


    }

    private static void printModel(Model model) {
        System.out.println("Namespaces: ");
        for (Namespace n : model.getNamespaces()) {
            System.out.println(n);
        }
        System.out.println("\n\n");
        Iterator<Statement> statementIterator = model.iterator();
        while (statementIterator.hasNext()) {
            System.out.println(statementIterator.next());
        }


    }

    private static Model calcualteClosest(Model tcnModel, List<Model> officeModels) {
        Model closestModel = null;
        double closestDistance = 999999999;
        double tcnLat = getLatitudeFromModel(tcnModel);
        double tcnLong = getLongitudeFromModel(tcnModel);
        for (Model m : officeModels) {
            double officeLat = getLatitudeFromModel(m);
            double officeLong = getLongitudeFromModel(m);
            double dist = Math.sqrt((officeLat - tcnLat) * (officeLat - tcnLat)
                    + (officeLong - tcnLong) * (officeLong - tcnLong));
            if (dist < closestDistance) {
                closestDistance = dist;
                closestModel = m;
            }
        }

        return closestModel;

    }

    private static Double getLatitudeFromModel(Model model) {
        ValueFactory factory = SimpleValueFactory.getInstance();
        IRI latitudeIRI = factory.createIRI("http://welcome/services/1.0/latitude");
        Set<Value> values = model.filter(null, latitudeIRI, null).objects();
        assert values.size() > 0;
        try {
            return Double.parseDouble(values.iterator().next().stringValue());
        } catch (NumberFormatException | NullPointerException ex) {
            throw ex;
        }
    }

    private static Double getLongitudeFromModel(Model model) {
        ValueFactory factory = SimpleValueFactory.getInstance();
        IRI latitudeIRI = factory.createIRI("http://welcome/services/1.0/longitude");
        Set<Value> values = model.filter(null, latitudeIRI, null).objects();
        assert values.size() > 0;
        try {
            return Double.parseDouble(values.iterator().next().stringValue());
        } catch (NumberFormatException | NullPointerException ex) {
            throw ex;
        }
    }

    public static Model generateModel() {
        String jsonLdExpand = "{\"@id\":\"http://welcome/services/1.0/dip1\",\"@type\":[\"http://welcome/services/1.0/DIP_request_info\"],\"http://welcome/services/1.0/dip_TCNname\":[{\"@value\":\"Karim T\"}],\"http://welcome/services/1.0/dip_age\":[{\"@value\":\"26\"}],\"http://welcome/services/1.0/dip_countryOrigin\":[{\"@value\":\"Syria\"}],\"http://welcome/services/1.0/dip_residence_address_city\":[{\"@value\":\"unknown\"}],\"http://welcome/services/1.0/dip_residence_address_number\":[{\"@value\":\"unknown\"}],\"http://welcome/services/1.0/dip_residence_address_street\":[{\"@value\":\"unknown\"}],\"http://welcome/services/1.0/dip_time_arrival_current_residence\":[{\"@value\":\"unknown\"}]}";
        String rdfInput = "@prefix welcome: <http://welcome/services/1.0/> .\n" +
                "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n" +
                "welcome:TCN_Location a welcome:Location ;\n" +
                "    welcome:latitude \"49.160155\";\n" +
                "    welcome:longitude \"8.000141\";\n" +
                "    welcome:address_name \"Saarbrucken\".\n" +
                "\n" +
                "\n" +
                "welcome:Office1 a welcome:Office;\n" +
                "    welcome:latitude \"49.073866\" ;\n" +
                "    welcome:longitude \"9.319362\";\n" +
                "    welcome:address_name \"Stutgart\".\n" +
                "\n" +
                "welcome:Office2 a welcome:Office; \n" +
                "    welcome:latitude \"50.127622\" ;\n" +
                "    welcome:longitude \"50.127622\";\n" +
                "    welcome:address_name \"Frankfurt\".\n" +
                "\n" +
                "welcome:Office3 a welcome:Office;\n" +
                "    welcome:latitude \"52.409121\" ;\n" +
                "    welcome:longitude \"13.408944\";\n" +
                "    welcome:address_name \"Berlin\".";

        InputStream inputStream = new ByteArrayInputStream(trigINP.getBytes());


        Model model = null;
        try {
            model = Rio.parse(inputStream, "", RDFFormat.TRIG);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }


//        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
//        RDFWriter writer = Rio.createWriter(RDFFormat.JSONLD, outputStream);
//        Rio.write(model, writer);

        String rdf4jServer = "http://localhost:8090/rdf4j";
        String repositoryID = "tst";
        Repository repo = new HTTPRepository(rdf4jServer, repositoryID);
        try (RepositoryConnection connection = repo.getConnection()) {
            connection.begin(IsolationLevels.SERIALIZABLE);
            model.forEach((stmt) -> {
                connection.add(stmt.getSubject(), stmt.getPredicate(), stmt.getObject(), stmt.getContext());
            });
            connection.commit();
        }
        return model;
    }

    private static void accessRemoteRepo() {

        String graphDBServer = "http://localhost:7200";
        String repositoryID = "agents";
//        String sparqlQuery = "SELECT * WHERE {?s ?p ?o .}";
        Repository repo = new HTTPRepository(graphDBServer, repositoryID);
//        RepositoryManager repositoryManager = new RemoteRepositoryManager(graphDBServer);
//        repositoryManager.initialize();

//        Repository repository = repositoryManager.getRepository(repositoryID);

        try (RepositoryConnection connection = repo.getConnection()) {
//            Query query = connection.prepareQuery(sparqlQuery);
            RepositoryResult<Statement> statements = connection.getStatements(null, null, null);
            while (statements.hasNext()) {
                System.out.println("-- " + statements.next());
            }
        }


    }

    private static void sendPostRequest() throws IOException {
        String query = "@prefix : <http://localhost:8090/rdf4j/repositories/welcome_ontology#> .\n" +
                "@prefix owl: <http://www.w3.org/2002/07/owl#> .\n" +
                "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n" +
                "@prefix xml: <http://www.w3.org/XML/1998/namespace> .\n" +
                "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .\n" +
                "@prefix ajan: <http://www.ajan.de/ajan-ns#> .\n" +
                "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\n" +
                "@prefix actor: <http://www.daml.org/services/owl-s/1.1/ActorDefault.owl#> .\n" +
                "@prefix http-core: <http://www.w3.org/2006/http#>.\n" +
                "\n" +
                ":initialization rdf:type ajan:AgentInitialisation .\n" +
                ":initialization ajan:agentName \"TestAgent2\"^^xsd:string .\n" +
                "\n" +
                ":initialization ajan:agentTemplate <http://localhost:8090/rdf4j/repositories/agents#WelcomeAgent> .\n" +
                "\n" +
                ":initialization ajan:agentInitKnowledge <http://localhost:8080/WelcomeServiceDescriptions/welcome_ontology#> .\n" +
                "<http://localhost:8080/WelcomeServiceDescriptions/welcome_ontology#> rdf:type owl:Ontology .\n" +
                "\n" +
                ":initialization ajan:agentInitKnowledge :ActiveAgents.\n" +
                ":initialization ajan:agentInitKnowledge :TRForm.\n" +
                "\n" +
                ":ActiveAgents http-core:requestURI \"http://localhost:8092/dispatcher/activeAgents\".\n" +
                ":TRForm http-core:requestURI \"http://localhost:8092/dispatcher/translationForm\".\n" +
                "\n";
        URL url = new URL("http://localhost:8080/welcome/integration/coordination/ajan/agents/");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "text/turtle; utf-8");
        con.setDoOutput(true);
        try (OutputStream os = con.getOutputStream()) {
            byte[] input = query.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            System.out.println(response.toString());
        }
    }

    private static void castToModel() {
        Object ex = "@prefix : <http://www.semanticweb.org/welcome#> .\n" +
                "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n" +
                "@prefix owl: <http://www.w3.org/2002/07/owl#> .\n" +
                "@prefix welcome: <https://raw.githubusercontent.com/gtzionis/WelcomeOntology/main/welcome.ttl#> .\n" +
                "\n" +
                "welcome:myWelcomeAgent9 rdf:type welcome:Handshaking .";

        Model model = (Model) ex;

    }
//    private static void createModel() throws IOException {
//        String jsonLdExpand = "{\"@id\":\"http://welcome/services/1.0/dip1\",\"@type\":[\"http://welcome/services/1.0/DIP_request_info\"],\"http://welcome/services/1.0/dip_TCNname\":[{\"@value\":\"Karim T\"}],\"http://welcome/services/1.0/dip_age\":[{\"@value\":\"26\"}],\"http://welcome/services/1.0/dip_countryOrigin\":[{\"@value\":\"Syria\"}],\"http://welcome/services/1.0/dip_residence_address_city\":[{\"@value\":\"unknown\"}],\"http://welcome/services/1.0/dip_residence_address_number\":[{\"@value\":\"unknown\"}],\"http://welcome/services/1.0/dip_residence_address_street\":[{\"@value\":\"unknown\"}],\"http://welcome/services/1.0/dip_time_arrival_current_residence\":[{\"@value\":\"unknown\"}]}";
//        String rdfInput = "@prefix welcome: <http://welcome/services/1.0/> .\n" +
//                "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n" +
//                "welcome:TCN_Location a welcome:Location ;\n" +
//                "    welcome:latitude \"49.160155\";\n" +
//                "    welcome:longitude \"8.000141\";\n" +
//                "    welcome:address_name \"Saarbrucken\".\n" +
//                "\n" +
//                "\n" +
//                "welcome:Office1 a welcome:Office;\n" +
//                "    welcome:latitude \"49.073866\" ;\n" +
//                "    welcome:longitude \"9.319362\";\n" +
//                "    welcome:address_name \"Stutgart\".\n" +
//                "\n" +
//                "welcome:Office2 a welcome:Office; \n" +
//                "    welcome:latitude \"50.127622\" ;\n" +
//                "    welcome:longitude \"50.127622\";\n" +
//                "    welcome:address_name \"Frankfurt\".\n" +
//                "\n" +
//                "welcome:Office3 a welcome:Office;\n" +
//                "    welcome:latitude \"52.409121\" ;\n" +
//                "    welcome:longitude \"13.408944\";\n" +
//                "    welcome:address_name \"Berlin\".";
//        InputStream inputStream = new ByteArrayInputStream(rdfInput.getBytes());
//
//
//        Model model = Rio.parse(inputStream, "", RDFFormat.TURTLE);
//
//
//        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
//        RDFWriter writer = Rio.createWriter(RDFFormat.JSONLD, outputStream);
//        Rio.write(model, writer);
//
//        InputStream inputStream1 = new ByteArrayInputStream(outputStream.toByteArray());
//
//        Object jsonObject = JsonUtils.fromInputStream(inputStream1);
//
//
//        Map context = new HashMap();
//        for (Namespace n : model.getNamespaces()) {
//            context.put(n.getPrefix(), n.getName());
//        }
//
//
//        JsonLdOptions options = new JsonLdOptions();
////        Object compact = JsonLdProcessor.compact(jsonObject, context, options);
//
//
//        System.out.println("-------");
////        System.out.println(JsonUtils.toPrettyString(compact));
////        System.out.println(JsonUtils.toString(compact));
////        ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();
////        ObjectOutputStream objectOutputStream=new ObjectOutputStream(byteArrayOutputStream);
////        objectOutputStream.writeObject(compact);
////        objectOutputStream.flush();
//
//
//        System.out.println("----------------COMPACT FORM-----------------------------------");
////        System.out.println(JsonUtils.toPrettyString(compact));
//        System.out.println("----------------COMPACT FORM-----------------------------------");
//
//
//        //-----------------------------------------------------------------------
////        RDFParser rdfParser = new TurtleParser();
////
////        Object rob = JsonLdProcessor.fromRDF(model);
////        System.out.println("-------------------------MODEL---------------");
////
////        System.out.println(model);
////        System.out.println("-------------------------MODEL---------------");
//
////        Object jsnobj = JsonUtils.fromInputStream(input);
////        Set<Namespace> namespaceSet = model.getNamespaces();
//
//
////        System.out.println(JsonUtils.toPrettyString(jsnobj));
//
////        RDFWriterRegistry rdfWriterRegistry = RDFWriterRegistry.getInstance();
////        Optional<RDFFormat> rdfFormat = rdfWriterRegistry.getFileFormatForMIMEType("application/ld+json");
////
////        JSONLDMode[] jsonldModes = new JSONLDMode[]{JSONLDMode.COMPACT, JSONLDMode.EXPAND, JSONLDMode.FLATTEN};
////        for (int i = 0; i < 3; i++) {
////            OutputStream outputStream = new ByteArrayOutputStream();
////
////            RDFWriter writer = Rio.createWriter(rdfFormat.get(), outputStream);
////            System.out.println("-------------------------outputstream---"+jsonldModes[i].getLabel()+"---------------");
////            writer.set(JSONLDSettings.JSONLD_MODE, jsonldModes[i]);
////            writer.startRDF();
////            for (Statement s : model) {
////                writer.handleStatement(s);
////            }
////            writer.endRDF();
////
////            System.out.println(outputStream.toString());
////            System.out.println("-------------------------outputstream---"+jsonldModes[i].getLabel()+"---------------");
////
////        }
//
//        //        writer.getWriterConfig().set(JSONLDSettings.JSONLD_MODE,JSONLDMode.COMPACT);
////        writer.getWriterConfig().set(JSONLDSettings.OPTIMIZE, true);
//
//        //-----------------------------------------------------------------------
//
////        Object compact = JsonLdProcessor.compact(jsonObject, context, options);
////
////        System.out.println("---------------------------------------------------");
////        System.out.println(JsonUtils.toPrettyString(compact));
////        System.out.println("---------------------------------------------------");
//
//    }

    private static void parse() {
        String rdf =
                "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n" +
                        "PREFIX welcome: <http://welcome/services/1.0/> \n" +


                        "CONSTRUCT {\n" +
                        "?dip rdf:type welcome:DIP_request_info .\n" +
                        "?dip welcome:dip_TCNname ?TCNname .\n" +
                        "?dip welcome:dip_age ?age .\n" +
                        "?dip welcome:dip_countryOrigin ?country .\n" +
                        "?dip welcome:dip_residence_address_city ?city .\n" +
                        "?dip welcome:dip_residence_address_street ?street .\n" +
                        "?dip welcome:dip_residence_address_number ?streetNumber .\n" +
                        "?dip welcome:dip_time_arrival_current_residence ?arrival .\n" +
                        "}\n" +
                        "WHERE {\n" +
                        "?dip rdf:type welcome:DIP_request_info .\n" +
                        "?dip welcome:dip_TCNname ?TCNname .\n" +
                        "\t\t\t\t\t?dip welcome:dip_age ?age .\n" +
                        "\t\t\t\t\t?dip welcome:dip_countryOrigin ?country .\n" +
                        "\t\t\t\t\t?dip welcome:dip_residence_address_city ?city .\n" +
                        "\t\t\t\t\t?dip welcome:dip_residence_address_street ?street .\n" +
                        "\t\t\t\t\t?dip welcome:dip_residence_address_number ?streetNumber .\n" +
                        "\t\t\t\t\t?dip welcome:dip_time_arrival_current_residence ?arrival .\n" +
                        "\t\t\t\t}";

        String prx = "prefix";
        String ikiNoqte = ":";
        String iriInd = "<";
        String iriInd2 = ">";

        int prfInd = rdf.indexOf(prx);
        int iriIndx = rdf.indexOf(iriInd);
        int iriIndx2 = rdf.indexOf(iriInd2);
        System.out.println(rdf.substring(prfInd, iriIndx2));


        List<Namespace> namespaces = new ArrayList<>();

        String[] prefixArray = rdf.trim().split("CONSTRUCT");
//        System.out.println(prefixArray[0]);
        String[] prefixesArray = prefixArray[0].trim().split("PREFIX");

        for (int i = 1; i < prefixesArray.length; i++) {
            namespaces.add(new SimpleNamespace(prefixesArray[i].split(":")[0],
                    prefixesArray[i].split("(.)*(<)")[1].replace(">", "")));
//            prefixes.put(prefixesArray[i].split(":")[0],
//                    prefixesArray[i].split("(.)*(<)")[1].replace(">",""));
        }

//        for (String string : prefixesArray) {
//            prefixes.put(string.split(":")[0],
//                    string.split("(.)*(<)")[1].replace(">",""));
//        }

        String s = "rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n";
//        System.out.println("77777777777777777777777777");
//        for (Object str:prefixes.entrySet()) {
//            System.out.println("str = " + str);
//        }
        for (Namespace nms : namespaces) {
//            System.out.println("nms = " + nms);
        }
    }

    private static void queryParse() throws IOException/*, InvalidSPARQLException */{
        String query = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n" +
                "PREFIX welcome: <http://welcome/services/1.0/> \n" +
                "CONSTRUCT {\n" +
                "?dip rdf:type welcome:DIP_request_info .\n" +
                "?dip welcome:dip_TCNname ?TCNname .\n" +
                "?dip welcome:dip_age ?age .\n" +
                "?dip welcome:dip_countryOrigin ?country .\n" +
                "?dip welcome:dip_residence_address_city ?city .\n" +
                "?dip welcome:dip_residence_address_street ?street .\n" +
                "?dip welcome:dip_residence_address_number ?streetNumber .\n" +
                "?dip welcome:dip_time_arrival_current_residence ?arrival .\n" +
                "}\n" +
                "WHERE {\n" +
                "?dip rdf:type welcome:DIP_request_info .\n" +
                "?dip welcome:dip_TCNname ?TCNname .\n" +
                "?dip welcome:dip_age ?age .\n" +
                "?dip welcome:dip_countryOrigin ?country .\n" +
                "?dip welcome:dip_residence_address_city ?city .\n" +
                "?dip welcome:dip_residence_address_street ?street .\n" +
                "?dip welcome:dip_residence_address_number ?streetNumber .\n" +
                "?dip welcome:dip_time_arrival_current_residence ?arrival .\n" +
                "}";

//        SPARQLQuery sparqlQuery = new SPARQLQuery(query);

    }
/*
    private static void convertLocation2Coordinates(String location) throws IOException {
        location = "Paris, France";
        Geocoder geocoder = new Geocoder();
        GeocoderRequest geocoderRequest = new GeocoderRequestBuilder()
                .setAddress(location)
//                .setLanguage("en")
                .getGeocoderRequest();
//        geocoderRequest.setAddress(location);


        GeocodeResponse geocodeResponse = geocoder.geocode(geocoderRequest);

        GeocoderStatus geocoderStatus = geocodeResponse.getStatus();
        System.out.println("geocoderStatus.value() = " + geocoderStatus.value());
        System.out.println("geocoderStatus.name() = " + geocoderStatus.name());
        System.out.println("geocoderStatus.toString() = " + geocoderStatus.toString());
        List<GeocoderResult> geocoderResults = geocodeResponse.getResults();
        System.out.println("geocoderResults.size() = " + geocoderResults.size());
        for (GeocoderResult geocoderResult : geocoderResults) {
            GeocoderGeometry geocoderGeometry = geocoderResult.getGeometry();
            LatLng latLng = geocoderGeometry.getLocation();
            System.out.println("latLng.getLat() = " + latLng.getLat());
            System.out.println("latLng.getLng() = " + latLng.getLng());
        }
    }

    private static void geocoder() {
        try {
            URL url = new URL(
                    "https://maps.googleapis.com/maps/api/geocode/json?address="
                            + URIUtil.encodeQuery("Sayaji Hotel, Near balewadi stadium, pune") + "&sensor=false"
                            + "&key=AIzaSyA_CREjAE-du9BqC1_cKKBR2gq-h2k5g20");

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

            String output = "", full = "";
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                full += output;
            }
            System.out.println("full = " + full);
//            PincodeVerify gson = new Gson().fromJson(full, PincodeVerify.class);
//            response = new IsPincodeSupportedResponse(new PincodeVerifyConcrete(
//                    gson.getResults().get(0).getFormatted_address(),
//                    gson.getResults().get(0).getGeometry().getLocation().getLat(),
//                    gson.getResults().get(0).getGeometry().getLocation().getLng())) ;
//            try {
//                String address = response.getAddress();
//                Double latitude = response.getLatitude(), longitude = response.getLongitude();
//                if (address == null || address.length() <= 0) {
//                    log.error("Address is null");
//                }
//            } catch (NullPointerException e) {
//                log.error("Address, latitude on longitude is null");
//            }
            conn.disconnect();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void createModelFromZero() {

        /*
@prefix :         <http://www.dfki.de/SmartMaaS/feedback#> .
@prefix owl:     <http://www.w3.org/2002/07/owl#> .
@prefix rdf:     <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix xml:     <http://www.w3.org/XML/1998/namespace> .
@prefix xsd:     <http://www.w3.org/2001/XMLSchema#> .
@prefix rdfs:    <http://www.w3.org/2000/01/rdf-schema#> .
@prefix time:    <http://www.w3.org/2006/time#> .
@prefix geo:    <http://www.w3.org/2003/01/geo/wgs84_pos#> .
@base <http://www.dfki.de/SmartMaaS/feedback> .

:Feedback1
    a :Feedback;
    :becauseOf ( [ a :TrafficJam ] [a :PotHole]);
    :hasTimestamp [
        time:xsdDateTime "CCYY-MM-DDThh:mm:ss.sss"^^xsd:dateTime ;
        :timeStampOf :Feedback1
    ];
    :causedDelay [
        time:hasXSDDuration ""^^xsd:Duration
    ];
    :atLocation [
        :locationOf :Feedback1;
        geo:long "12.34";
        geo:lat "2.34";
        :Address "adress"^^xsd:string
    ];
    :affects [
        a :Bus;
        :affectedBy :Feedback1;
        :Line "BusLine"^^xsd:string
    ] .
        :Feedback :instanceAmount "n".
*/
/*
        ValueFactory vf = SimpleValueFactory.getInstance();
        ModelBuilder modelBuilder = new ModelBuilder();

        String base = "http://www.dfki.de/SmartMaaS/feedback/";
        modelBuilder.setNamespace("base", "http://www.dfki.de/SmartMaaS/feedback#")
                .setNamespace("owl", "http://www.w3.org/2002/07/owl#")
                .setNamespace("rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#")
                .setNamespace("xml", "http://www.w3.org/XML/1998/namespace#")
                .setNamespace("xsd", "http://www.w3.org/2001/XMLSchema#")
                .setNamespace("rdfs", "http://www.w3.org/2000/01/rdf-schema#")
                .setNamespace("time", "http://www.w3.org/2006/time#")
                .setNamespace("geo", "http://www.w3.org/2003/01/geo/wgs84_pos#");


        Resource becauseOfHead = vf.createBNode();
        Resource timeStampHead = vf.createBNode();
        Resource delayHead = vf.createBNode();
        Resource locationHead = vf.createBNode();
        Resource vehicleHead = vf.createBNode();


        modelBuilder.subject("base:Feedback_n")
                .add(RDF.TYPE, "base:Feedback")
                .add("base:hasTimestamp", timeStampHead)
                .subject(timeStampHead)
                .add("time:xsdDateTime", "2020-11-26,23:18")
                .add("base:timeStampOf", "base:Feedback_n")
                .subject("base:Feedback_n")
                .add("base:causedDelay", delayHead)
                .subject(delayHead)
                .add("time:hasCSDDuration", "PT5M")
                .subject("base:Feedback_n")
                .add("base:atLocation", locationHead)
                .subject(locationHead)
                .add("base:locationOf", "base:Feedback_n")
                .add("geo:long", "12.36")
                .add("geo:lat", "2.3")
                .add("base:Address", "Waldhausweg 17")
                .subject("base:Feedback_n")
                .add("base:affects", vehicleHead)
                .subject(vehicleHead)
                .add(RDF.TYPE, "base:Bus")
                .add("base:affectedBy", "base:Feedback_n")
                .add("base:Line", "Berlin-Munich")
                .subject("base:Feedback_n")
                .add("base:becauseOf", becauseOfHead);


        List<IRI> reasons = Arrays.asList(vf.createIRI(base, "TrafficJam"), vf.createIRI(base, "Pothole"));
        List<Statement> statements = RDFCollections.asRDF(reasons, becauseOfHead, new ArrayList<>());

        Model model = modelBuilder.build();


        model.addAll(statements);

        /*:Feedback1
    a :Feedback;
    :becauseOf ( [ a :TrafficJam ] [a :PotHole]);
    :hasTimestamp [
        time:xsdDateTime "CCYY-MM-DDThh:mm:ss.sss"^^xsd:dateTime ;
        :timeStampOf :Feedback1
    ];
    :causedDelay [
        time:hasXSDDuration ""^^xsd:Duration
    ];
    :atLocation [
        :locationOf :Feedback1;
        geo:long "12.34";
        geo:lat "2.34";
        :Address "adress"^^xsd:string
    ];
    :affects [
        a :Bus;
        :affectedBy :Feedback1;
        :Line "BusLine"^^xsd:string
    ] .
        :Feedback :instanceAmount "n".*/
/*
        System.out.println("Begin------1111111111111111------------");
//        printModel(model);
        System.out.println("model.toString() = \n" + model.toString());
        StringBuilder stringBuilder = new StringBuilder();
        for (Statement s : model) {
            stringBuilder.append(s);
        }
        String stringOfModel = stringBuilder.toString();
        System.out.println("stringOfModel = \n" + stringOfModel);
        System.out.println("End------1111111111111111------------");

        System.out.println("Begin------2222222222222------------");

        String string_model = null;
        try {
            OutputStream outputStream = new ByteArrayOutputStream();
            RDFWriter rdfWriter = Rio.createWriter(RDFFormat.TURTLE, outputStream);
            Rio.write(model, rdfWriter);

            string_model = outputStream.toString();
            outputStream.close();
            System.out.println(string_model);

        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        System.out.println("End------2222222222222------------");

        System.out.println("Begin------3333333333333333------------");
        string_model = string_model.replaceAll("Feedback_n", "Feedback_5");
        System.out.println("string_model = " + string_model);
        System.out.println("End------3333333333333333------------");

        System.out.println("Begin------44444444444444------------");

        InputStream inputStream = new ByteArrayInputStream(string_model.getBytes());
        Model new_model = null;
        try {
            new_model = Rio.parse(inputStream, base, RDFFormat.TURTLE);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        printModel(new_model);
        System.out.println("End------44444444444444------------");


        System.out.println("Begin------555555555555555------------");

        InputStream inputStream2 = new ByteArrayInputStream(stringOfModel.getBytes());
        Model new_model2 = null;
        try {
            new_model2 = Rio.parse(inputStream2, base, RDFFormat.TURTLE);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        printModel(new_model2);
        System.out.println("End------555555555555555------------");
    }

    private static void convert2CollectionTest() {
        String ns = "http://www.dfki.de/SmartMaaS/feedback/";
        ValueFactory vf = SimpleValueFactory.getInstance();

// IRI for ex:favoriteLetters
        IRI beauseOf = vf.createIRI(ns, "becauseOf");
// IRI for ex:John
        IRI feedback = vf.createIRI(ns, "Feedback1");
// create a list of letters
        IRI tJam = vf.createIRI(ns, "Jam");

        List<Literal> reasons = Arrays.asList(vf.createLiteral(ns, "TrafficJam"), vf.createLiteral(ns, "Pothole"));
        List<IRI> iris = Arrays.asList(tJam, vf.createIRI(ns, "Pothole"));

        // create a head resource for our list
        Resource head = vf.createBNode();
// convert our list and add it to a newly-created Model
//        Model model = RDFCollections.asRDF(iris, head, new LinkedHashModel());

        ModelBuilder modelBuilder = new ModelBuilder();
        modelBuilder.setNamespace(":", "http://www.dfki.de/SmartMaaS/feedback");
        modelBuilder.subject(":Feedback1")
                .add(RDF.TYPE, "Feedback")
                .add(beauseOf, head);

        List<Statement> statements = RDFCollections.asRDF(iris, head, new ArrayList<>());
        Model model = modelBuilder.build();
        model.addAll(statements);

// set the ex:favoriteLetters property to link to the head of the list
//        model.add(feedback, beauseOf, head);

//        model.add(feedback, beauseOf, head);

        printModel(model);
    }

    private static void getBytesFromRDF4JModel() {
        ModelBuilder modelBuilder = new ModelBuilder();
        Model model = modelBuilder.build();


    }

    private static void testingRegex() {
        String str = "http://www.dfki.de/SmartMaaS/feedback#Feedback014568";
        String regex = ".+#(Feedback|feedback)\\d+";
        String uful = str.replaceAll(".+#(Feedback|feedback)", "");
        boolean res = str.matches(regex);
        System.out.println("res = " + res);
        System.out.println("uful = " + uful);

    }

    private static void testingBlankNode() {
        ValueFactory valueFactory = SimpleValueFactory.getInstance();

        BNode bNode = valueFactory.createBNode();
        IRI bob = valueFactory.createIRI("http://example.org/Blanknode");
        IRI name = valueFactory.createIRI("http://example.org/is");
        Literal literal = valueFactory.createLiteral("BOB");
        IRI iri = valueFactory.createIRI("http://example.org/BlankNode");


        Statement statement = valueFactory.createStatement(bob, name, bNode);

        Model model = new LinkedHashModel();
        model.add(statement);
        model.add(bNode, name, bob);

        System.out.println("statement.toString() = " + statement.toString());


        printModel(model);
    }

    private static void testingCreateLiteralWithXSDString() {
        ValueFactory valueFactory = SimpleValueFactory.getInstance();
        Literal literal = valueFactory.createLiteral("salam", valueFactory.createIRI("http://www.w3.org/2001/XMLSchema#", "Duration"));
        System.out.println(literal);
        Literal literal1 = valueFactory.createLiteral("eleyke", "xsd:Duration");
        System.out.println("literal1 = " + literal1);

    }

*/}
}