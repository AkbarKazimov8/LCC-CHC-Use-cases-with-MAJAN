package general;

public class ElementOfMultiset
{
	public int element;
	
	public int repetition; 
 	
	 
	public ElementOfMultiset( int element, int repetition )
	{
		this.element = element;
		this.repetition = repetition;
	}
}