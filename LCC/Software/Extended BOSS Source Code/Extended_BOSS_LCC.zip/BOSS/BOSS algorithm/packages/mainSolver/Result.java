package mainSolver;
import inputOutput.Input;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import general.Combinations;
import general.General;
import ipSolver.IntegerPartitionGraph;
import ipSolver.IDPSolver_whenRunning_ODPIP;
import ipSolver.ODPSolver_runningInParallelWithIP;
public class Result
{
	public Result( Input input )  
	{
		totalNumOfCS = Combinations.getNumOfCS( input.numOfAgents );
		totalNumOfCoalitionsInSearchSpace = Combinations.getNumOfCoalitionsInSearchSpace( input.numOfAgents );
		dpMaxSizeThatWasComputedSoFar = 1;
	}
	public int       numOfAgents;  
	public long      totalNumOfCS; 
	public long      totalNumOfCoalitionsInSearchSpace; 
	public long      totalNumOfExpansions; 
	public IDPSolver_whenRunning_ODPIP idpSolver_whenRunning_ODPIP;
	public ODPSolver_runningInParallelWithIP odpSolver_runningInParallelWithIP;
	public long     inclusionExclusionTime; 
	public double   inclusionExclusionTime_confidenceInterval; 
	public  int[][] inclusionExclusionBestCSFound; 
	public  double  inclusionExclusionValueOfBestCSFound; 
	public double   inclusionExclusionValueOfBestCSFound_confidenceInterval; 
	public long     cplexTime;  
	public double   cplexTime_confidenceInterval; 
	public  int[][] cplexBestCSFound; 
	public  double  cplexValueOfBestCSFound; 
	public double   cplexValueOfBestCSFound_confidenceInterval; 
	private  int     dpMaxSizeThatWasComputedSoFar;  
	private  boolean dpHasFinished;  
	private  int[][] dpBestCSFound;  
	private  double  dpValueOfBestCSFound;  
	public long      dpTime;  
	public long[]    dpTimeForEachSize ;  
	private  int[][] ipBestCSFound;  
	private  double  ipValueOfBestCSFound;  
	public double    ipValueOfBestCS_confidenceInterval;  
	public long      ipStartTime;  
	public double    ipTimeForScanningTheInput_confidenceInterval;  
	public long      ipTime;  
	public double    ipTime_confidenceInterval;  
	public long      ipTimeForScanningTheInput;  
	public long      ipNumOfExpansions;  
	public double    ipNumOfExpansions_confidenceInterval;  
	public double    ipUpperBoundOnOptimalValue;  
	public double    ipUpperBoundOnOptimalValue_confidenceInterval;  		
	public double    ipLowerBoundOnOptimalValue;  
	public IntegerPartitionGraph ipIntegerPartitionGraph;  
	private double[]  max_f; 
	// <start> LCC related 

	private List<int[][]> topTenCSs;
	private List<Integer> topTenCSInBit;
	private List<Double> topTenCSValues;
	// <end> LCC related 

	public void initializeIPResults(){
		ipStartTime=System.currentTimeMillis();
		ipNumOfExpansions=0;
		ipValueOfBestCSFound=Double.NEGATIVE_INFINITY;
		ipBestCSFound = null;
		totalNumOfExpansions = 0;
		// <start> LCC related 
		topTenCSs=new ArrayList<int[][]>(10);
		topTenCSValues=new ArrayList<Double>(10);
		dpValueOfBestCSFound = Double.NEGATIVE_INFINITY;
		topTenCSInBit=new ArrayList<Integer>();
		// <end> LCC related 

	}
	public void updateDPSolution( int[][] CS, double value ){
//		System.out.println("CS to be added as the best DP solution\n:::"+General.convertArrayToString(CS));

		if( get_dpValueOfBestCSFound() <= value ){
			set_dpValueOfBestCSFound( value );
			set_dpBestCSFound( General.copyArray(CS) );
		}
	}
	public synchronized void updateIPSolution( int[][] CS, double value ){
//		System.out.println("CS to be added as the best IP solution\n:::"+General.convertArrayToString(CS));
    	
		if( get_ipValueOfBestCSFound() <= value ){
			set_ipValueOfBestCSFound( value );
			set_ipBestCSFound( General.copyArray(CS) );
		}
	}
	// <start> LCC related 

	
	// Each CS with its value comes here. Top ten best CSs are stored
	public synchronized void updateSolutionList(int[][] CS, double value) {
		int csInBit = Combinations.convertCombinationFromByteToBitFormat(Combinations.convertSetOfCombinationsFromByteToBitFormat(CS));
		System.out.println("CS to be added to IP solutions list:::"+General.convertArrayToString(CS)+"-bitFormat:"+csInBit);
		if(!topTenCSInBit.contains(csInBit)) {
			int limit= 30;
		

		if(topTenCSValues.size()==0) {
			topTenCSs.add(CS);
			topTenCSValues.add(value);
			topTenCSInBit.add(csInBit);
		}else {
			int size = ((topTenCSs.size()>limit) ?  limit : topTenCSs.size());
		//	int size = topTenCSs.size();
			for (int i = 0; i < size; i++) {
				if(value>=topTenCSValues.get(i)) {
					for (int j = size-1; j >= i; j--) {
						if(size!=j+1) {
							topTenCSs.set(j+1, topTenCSs.get(j));
							topTenCSValues.set(j+1, topTenCSValues.get(j));
							topTenCSInBit.set(j+1, topTenCSInBit.get(j));
						}else {
							topTenCSs.add(j+1, topTenCSs.get(j));
							topTenCSValues.add(j+1, topTenCSValues.get(j));
							topTenCSInBit.add(j+1, topTenCSInBit.get(j));
						}
						
					}
					topTenCSs.set(i,CS);
					topTenCSValues.set(i, value);
					topTenCSInBit.set(i,csInBit);

					break;
				}
			}
		}
		if(topTenCSs.size()>limit) {
			for (int i = limit; i < topTenCSs.size(); i++) {
				topTenCSs.remove(i);
				topTenCSValues.remove(i);
				topTenCSInBit.remove(i);
				
			}
		}}
	}
	// <end> LCC related 

	 public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map) {
	        List<Entry<K, V>> list = new ArrayList<>(map.entrySet());
	        
	        list.sort(Entry.comparingByValue());

	        Map<K, V> result = new LinkedHashMap<>();
	        for (Entry<K, V> entry : list) {
	            result.put(entry.getKey(), entry.getValue());
	        }

	        return result;
	    }
	
	public synchronized void set_dpHasFinished( boolean dpHasFinished ){
		this.dpHasFinished = dpHasFinished;
	}
	public synchronized boolean get_dpHasFinished(){
		return dpHasFinished;
	}
	public synchronized void set_dpMaxSizeThatWasComputedSoFar( int size ){
		dpMaxSizeThatWasComputedSoFar = size;
	}
	public synchronized int get_dpMaxSizeThatWasComputedSoFar(){
		return dpMaxSizeThatWasComputedSoFar;
	}
	public synchronized void set_dpBestCSFound( int[][] CS ){
		dpBestCSFound = General.copyArray( CS );		
	}
	public synchronized int[][] get_dpBestCSFound(){
		return dpBestCSFound;		
	}
	public synchronized void set_dpValueOfBestCSFound(double value){
		dpValueOfBestCSFound = value;				
	}
	public synchronized double get_dpValueOfBestCSFound(){
		return dpValueOfBestCSFound;				
	}
	public   void set_ipBestCSFound( int[][] CS ){
		ipBestCSFound = General.copyArray( CS );		
	}
	public   int[][] get_ipBestCSFound(){
		return ipBestCSFound;		
	}
	public   void set_ipValueOfBestCSFound(double value){
		ipValueOfBestCSFound = value;				
	}
	public   double get_ipValueOfBestCSFound(){
		return ipValueOfBestCSFound;				
	}
	public void set_max_f( int index, double value){
		max_f[ index ] = value;
	}
	public double get_max_f( int index ){
		return( max_f[index] );
	}
	public void init_max_f( Input input, double[][] maxValueForEachSize ){
		max_f = new double[input.numOfAgents];
    	for( int i=0; i<input.numOfAgents; i++ )
    		set_max_f( i, 0 );
		for(int i=0; i<input.numOfAgents; i++){
			double value = input.getCoalitionValue( (1<<i) );  
			if( get_max_f( 0 ) < value )
				set_max_f( 0 ,   value );
		}
		for(int i=1; i<input.numOfAgents; i++)  
			set_max_f( i, maxValueForEachSize[i][0] );
	}
	public long getTotalNumOfCS() {
		return totalNumOfCS;
	}
	public List<int[][]> getTopTenCSs() {
		return topTenCSs;
	}
	public List<Double> getTopTenCSValues() {
		return topTenCSValues;
	}
	
	public String getTwoDigitAfterDot(double n) {
		return new DecimalFormat("###.###").format(n);
	}
}