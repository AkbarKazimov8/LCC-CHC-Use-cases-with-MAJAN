module CSGPCoalitionGeneration {
}