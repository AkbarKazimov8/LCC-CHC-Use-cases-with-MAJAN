package coalitionGeneration;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import models.Agent;
import models.CSGPInput;
import models.CannotLink;
import models.Coalition;
import models.MustLink;
import utils.Combinations;

public class Main {

	public static void main (String[] args) {

		long startTime = System.nanoTime();

		String inputPath="C:\\Users\\akka02\\Desktop\\Master-Thesis\\EclipseWorkspace\\CSGPCoalitionGeneration\\Input-Output\\input.txt";
		String outputPath="C:\\Users\\akka02\\Desktop\\Master-Thesis\\EclipseWorkspace\\CSGPCoalitionGeneration\\Input-Output\\output.txt";

		String inputFileForBOSSPath = "C:\\Users\\akka02\\Desktop\\Master-Thesis\\EclipseWorkspace\\BOSS_for_baseline\\BOSS algorithm\\Input-Output\\input.txt";
		
		CoalitionGeneration coalitionGeneration=new CoalitionGeneration();
		CSGPInput csgpInput=coalitionGeneration.readInputFromFile(inputPath);

		/*List<int[]> cls=csgpInput.getCLs();
		System.out.println("CLs size:"+cls.size());
		for (int[] is : cls) {
			System.out.println("Cannot Link: "+is[0]+", "+is[1]);	
		}*/
		
	/*	List<int[]> mls=csgpInput.getMLs();
		System.out.println("MLs size:"+mls.size());
		for (int[] is : mls) {
			System.out.println("Must Link: "+is[0]+", "+is[1]);	
		}*/

		//List<Coalition> coalitions= coalitionGeneration.generateCoalitions(csgpInput);
		
	List<Coalition> allCoalitions = coalitionGeneration.generateALLCoalitions(csgpInput);
		

		//System.out.println("Reduced number of coalitions:"+coalitions.size());
	
	//	System.out.println("All number of coalitions:"+allCoalitions.size());

	/*	for (Coalition coalition : coalitions) {
			System.out.println("Coalition ID:"+coalition.getID());
			System.out.println("Coalition:"+
			utils.General.convertArrayToString(Combinations.convertCombinationFromBitToByteFormat(coalition.getID(), 
					csgpInput.getAgents().size())));
			System.out.println("Value:"+coalition.getValue());


					System.out.println("length:"+
			Combinations.convertCombinationFromBitToByteFormat(coalition.getID(), csgpInput.getAgents().size()).length);

		}*/


		Output output=new Output();
		try {
			output.writeToFile(inputFileForBOSSPath, csgpInput.getAgents().size(), allCoalitions);
			//output.writeToFileAllCoalitions(outputPath, csgpInput.getAgents().size(), allCoalitions);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		long endTime   = System.nanoTime();
		long totalTime = endTime - startTime;
		System.out.println("Total Time:"+totalTime);
		System.out.println("Total Time in seconds:"+(double)totalTime/1000000000);
	}
}
