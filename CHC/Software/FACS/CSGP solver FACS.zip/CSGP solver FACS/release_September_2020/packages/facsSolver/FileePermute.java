package facsSolver;

public class FileePermute {
	int[] tete;
	int ind;
	FileePermute suivant;
	public FileePermute(int[] tete, int ind){
		this.tete=tete;
		this.ind=ind;
		suivant=null;
	}
}
