package dbscan;

public class Point 
{
	private int x;

	private int y;

	
	Point(int a, int b)
	 {
		x=a;
		y=b;
	 }
	
	public int getX ()
	 {

		return x;

	 }


	public int getY () 
	{

		return y;

	}

	

}

