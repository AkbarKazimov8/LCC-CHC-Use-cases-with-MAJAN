package predefinedExperiments;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import general.General;
import inputOutput.Input;
import inputOutput.SolverNames;
import inputOutput.ValueDistribution;
import mainSolver.MainSolver;
import mainSolver.Result;

public class RunDPAndIDPAndODP
{
	private String   str_numOfAgents;
	private String   str_dpTime;
	private String[] str_sizeConsideredByDP;
	private String[] str_numOfEvaluatedSplittings;
	private String[] str_dpTimeForEachSize;
	
	
	public void run( boolean readCoalitionValuesFromFile )
	{
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat( "yyyy-MM-dd (HH-mm-ss)" );

		Input input = initializeInput();
		
		for(int run=1; run<=3; run++) 
		{
			int minNumOfAgents = 15; int maxNumOfAgents = 23;

			initializeStringsOfResults( minNumOfAgents, maxNumOfAgents, run );
			
			for(input.numOfAgents=minNumOfAgents; input.numOfAgents<=maxNumOfAgents; input.numOfAgents++)
			{
				if( run == 1) 
				{
					input.solverName = SolverNames.ODP;
					input.outputFolder = "D:/CSGresults/ODP ";
					System.out.println("Now running ODP for "+input.numOfAgents+" agents");
				}
				if( run == 2) 
				{
					input.solverName = SolverNames.IDP;
					input.outputFolder = "D:/CSGresults/IDP ";
					System.out.println("Now running IDP for "+input.numOfAgents+" agents");
				}
				if( run == 3 ) 
				{
					input.solverName = SolverNames.DP;
					input.outputFolder = "D:/CSGresults/DP ";
					System.out.println("Now running DP for "+input.numOfAgents+" agents");
				}
				input.outputFolder += simpleDateFormat.format(calendar.getTime());
				
				General.createFolder( input.outputFolder );

				if( readCoalitionValuesFromFile ) input.readCoalitionValuesFromFile( 1 );
				else input.generateCoalitionValues();
				
				Result result = (new MainSolver()).solve( input );
				
				updateStringsOfResults( input, result );
				
				printCurrentResultsToFile( input );
			}			
			printFinalResultsToFile( input );
		}
	}
	
	private Input initializeInput()
	{
		Input input = new Input();
		
		input.storeCoalitionValuesInFile = false;
		input.printDetailsOfSubspaces = false;
		input.printNumOfIntegerPartitionsWithRepeatedParts = false;
		input.printInterimResultsOfIPToFiles = false;
		input.printTimeTakenByIPForEachSubspace = false;

		input.feasibleCoalitions = null;
		input.numOfRunningTimes = 1; 
		input.valueDistribution = ValueDistribution.UNIFORM;
		
		return( input );
	}
	
	private void initializeStringsOfResults( int minNumOfAgents, int maxNumOfAgents, int run )
	{
		if( run == 1 ) str_dpTime = "ODP_Time = [";
		if( run == 2 ) str_dpTime = "IDP_Time = [";
		if( run == 3 ) str_dpTime = "DP_Time = [";

		str_numOfAgents = "numOfAgents = [";

		str_sizeConsideredByDP          = new String[ maxNumOfAgents+1 ];
		str_numOfEvaluatedSplittings    = new String[ maxNumOfAgents+1 ];
		str_dpTimeForEachSize           = new String[ maxNumOfAgents+1 ];
		
		for(int numOfAgents=minNumOfAgents; numOfAgents<=maxNumOfAgents; numOfAgents++)
		{
			int dpMaxSize = numOfAgents;
			if( run == 2 )
				dpMaxSize = (int)(Math.floor( (2 * numOfAgents) / (double)3 ));
			
			str_sizeConsideredByDP[numOfAgents]          = "sizeConsideredByDP("+numOfAgents+","+1+":"+(dpMaxSize-1)+") = [";
			str_numOfEvaluatedSplittings[numOfAgents]    = "numOfEvaluatedSplittings("+numOfAgents+","+1+":"+(dpMaxSize-1)+") = [";
			str_dpTimeForEachSize[numOfAgents]           = "dpTimeForEachSize("+numOfAgents+","+1+":"+numOfAgents+") = [";
		}
	}
	
	private void updateStringsOfResults( Input input, Result result )
	{
		str_numOfAgents += input.numOfAgents+" ";
		str_dpTime += result.dpTime+" ";
		
    	long dpMaxSize = input.numOfAgents;
    	if( input.solverName == SolverNames.IDP )
    		dpMaxSize = (int)(Math.floor( (2 * input.numOfAgents) / (double)3 ));

		for(int size=2; size<=dpMaxSize; size++)
			str_sizeConsideredByDP[ input.numOfAgents ] += size+" ";

		for(int size=1; size<=input.numOfAgents; size++)
			str_dpTimeForEachSize[ input.numOfAgents ] += result.dpTimeForEachSize[size]+" ";
	}
	
	private void printCurrentResultsToFile( Input input )
	{
		String filePathAndName = input.outputFolder + "/NumOfPrunedSubspacesAndEvaluatedSplits.txt";

		General.printToFile( filePathAndName, "numOfAgents = "+input.numOfAgents+"\n", false);

		str_sizeConsideredByDP[ input.numOfAgents] += "]\n";
		General.printToFile( filePathAndName, str_sizeConsideredByDP[ input.numOfAgents], false);
		str_numOfEvaluatedSplittings[ input.numOfAgents] += "]\n";
		General.printToFile( filePathAndName, str_numOfEvaluatedSplittings[ input.numOfAgents], false);
		str_dpTimeForEachSize[ input.numOfAgents] += "]\n\n";
		General.printToFile( filePathAndName, str_dpTimeForEachSize[ input.numOfAgents], false);
	}
	
	
	private void printFinalResultsToFile( Input input )
	{
		String filePathAndName = input.outputFolder + "/totalRunTime.txt";

		str_numOfAgents += "]\n";
		General.printToFile( filePathAndName, str_numOfAgents, false);
		str_dpTime += "]\n\n";
		General.printToFile( filePathAndName, str_dpTime, false);
	}
}