package predefinedExperiments;

import general.Combinations;

public class NumOfEvaluatedSplitsByDPAndIDPAndODP
{
	public void run()
	{
		int minNumOfAgents = 5; int maxNumOfAgents = 40;

		long[] sumDP = new long[ maxNumOfAgents+1 ];
		long[] sumIDP = new long[ maxNumOfAgents+1 ];
		long[] sumODP = new long[ maxNumOfAgents+1 ];
		for(int numOfAgents=0; numOfAgents<=maxNumOfAgents; numOfAgents++){
			sumDP[numOfAgents]=0;
			sumIDP[numOfAgents]=0;
			sumODP[numOfAgents]=0;
		}
		for(int numOfAgents=minNumOfAgents; numOfAgents<=maxNumOfAgents; numOfAgents++){
			for(int sizeOfCoalitions=2; sizeOfCoalitions<=numOfAgents; sizeOfCoalitions++){
				sumIDP[numOfAgents] += computeNumOfSplitsEvaluatedByIDP(numOfAgents, sizeOfCoalitions ,false);
			}
			sumDP [numOfAgents]=(long)(0.5*(Math.pow(3,numOfAgents  )+1) - Math.pow(2,numOfAgents) );
			sumODP[numOfAgents]=(long)(0.5*(Math.pow(3,numOfAgents-1)-1)                           );
		}
		System.out.print("DP=[");
		for(int numOfAgents=minNumOfAgents; numOfAgents<=maxNumOfAgents; numOfAgents++)
			System.out.print( ((double)sumDP[numOfAgents]/sumDP[numOfAgents])  + " ");
		System.out.println("]");
		System.out.print("IDP=[");
		for(int n=minNumOfAgents; n<=maxNumOfAgents; n++)
			System.out.print( ((double)sumIDP[n]/sumDP[n])  + " ");
		System.out.println("]");
		System.out.print("ODP=[");
		for(int n=minNumOfAgents; n<=maxNumOfAgents; n++)
			System.out.print( ((double)sumODP[n]/sumDP[n])  + " ");
		System.out.println("]");
	}
	
	//*****************************************************************************************************
	
    private long computeNumOfSplitsEvaluatedByIDP(int numOfAgents, int sizeOfCoalitions, boolean efficientImplementation)
    {
    	if( sizeOfCoalitions == numOfAgents )
    	{
    		long numOfGrandCoalitionSplits = 1;
    		for(int size=1; size<=(numOfAgents-1)-1; size++)
    			numOfGrandCoalitionSplits += Combinations.binomialCoefficient((int)(numOfAgents-1), size);
    		return( numOfGrandCoalitionSplits );
    	}
    	long dpMaxSize = (int)(Math.floor( (2 * numOfAgents) / (double)3 ));

    	if(( dpMaxSize < sizeOfCoalitions )&&( sizeOfCoalitions < numOfAgents ))
    		return(0);

    	if(( 1 < sizeOfCoalitions )&&( sizeOfCoalitions < numOfAgents ))
    	{
    		long numOfCoalitionsOfCurSize = Combinations.binomialCoefficient((int)numOfAgents, sizeOfCoalitions);

    		long[] numOfPossibleSplitsBasedOnSizeOfFirstHalf = computeNumOfPossibleSplitsBasedOnSizeOfFirstHalf( sizeOfCoalitions );
    		long numOfEvaluatedSplitsOfOneCoalition=0;
    		for(int sizeOfFirstHalf=(int)Math.ceil(sizeOfCoalitions/(double)2); sizeOfFirstHalf<sizeOfCoalitions; sizeOfFirstHalf++)
    		{
    			if( efficientImplementation == false )
    				if(( sizeOfFirstHalf > numOfAgents-sizeOfCoalitions )&&( sizeOfCoalitions!=numOfAgents )) continue;

    			numOfEvaluatedSplitsOfOneCoalition += numOfPossibleSplitsBasedOnSizeOfFirstHalf[ sizeOfFirstHalf ];
    		}
    		return( numOfCoalitionsOfCurSize * (numOfEvaluatedSplitsOfOneCoalition) );
    	}else{
    		return(0);
    	}
    }

    //*****************************************************************************************************
    
    private long[] computeNumOfPossibleSplitsBasedOnSizeOfFirstHalf( int size )
    {
    	long[] numOfPossibleSplitsBasedOnSizeOfFirstHalf = new long[size];
    	for(int sizeOfFirstHalf=(int)Math.ceil(size/(double)2); sizeOfFirstHalf<size; sizeOfFirstHalf++){
    		int sizeOfSecondHalf = (int)(size - sizeOfFirstHalf);
    		if(( (size % 2) == 0 )&&( sizeOfFirstHalf == sizeOfSecondHalf ))
    			numOfPossibleSplitsBasedOnSizeOfFirstHalf[ sizeOfFirstHalf ] = Combinations.binomialCoefficient(size, sizeOfFirstHalf )/2;
    		else
    			numOfPossibleSplitsBasedOnSizeOfFirstHalf[ sizeOfFirstHalf ] = Combinations.binomialCoefficient(size, sizeOfFirstHalf );    		
    	}
    	return( numOfPossibleSplitsBasedOnSizeOfFirstHalf );
    }    
}