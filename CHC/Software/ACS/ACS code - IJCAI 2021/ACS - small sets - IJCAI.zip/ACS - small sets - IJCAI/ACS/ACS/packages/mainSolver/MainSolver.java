package mainSolver;

import acsSolver.*;
import general.Combinations;
import inputOutput.*;
import ipSolver.*;

public class MainSolver
{
	public Result solve( Input input )	
	{
		ComputeErrorBars computeErrorBars = new ComputeErrorBars(input); 

		for( int problemID=1; problemID<=input.numOfRunningTimes; problemID++)
		{			
			input.problemID = (new Integer(problemID)).toString();
			Result result = new Result(input);
			Output output = new Output();
			output.initOutput( input );

			if( input.storeCoalitionValuesInFile )
				input.storeCoalitionValuesInFile( problemID );
			
			if ( (input.solverName == SolverNames.DP) || (input.solverName == SolverNames.IDP) ){
				DPSolver dpSolver = new DPSolver(input, result); dpSolver.runDPorIDP();
			}
			else if ( (input.solverName == SolverNames.ACS) ){
				ACS dpSolver = new ACS(input, result); dpSolver.runACS();
			}
			else if ( (input.solverName == SolverNames.ODP) ){
				DPSolver dpSolver = new DPSolver(input, result); dpSolver.runODP();
			}
			else if ( (input.solverName == SolverNames.IP) || (input.solverName == SolverNames.ODPIP) ){
				IPSolver ipSolver = new IPSolver(); ipSolver.solve( input, output, result );
			}
			if( input.numOfRunningTimes == 1 ) {
				return( result );
			}else{
				computeErrorBars.addResults( result );
				if( problemID < input.numOfRunningTimes ){
					if( input.readCoalitionValuesFromFile )
						input.readCoalitionValuesFromFile( problemID+1 );
					else
						input.generateCoalitionValues();
				}
				System.out.println(input.numOfAgents+" agents, "+ValueDistribution.toString(input.valueDistribution)+" distribution. The solver just finished solving "+input.problemID+" problems out of  "+input.numOfRunningTimes);
			}
		}
		Result averageResult = computeErrorBars.setAverageResultAndConfidenceIntervals( input );
		return( averageResult );
	}
}