package EDP;

public class Filee {
	public Noeud tete;
	public Filee suivant;
	public Filee(Noeud tete){
		this.tete=tete;
		suivant=null;
	}
}
