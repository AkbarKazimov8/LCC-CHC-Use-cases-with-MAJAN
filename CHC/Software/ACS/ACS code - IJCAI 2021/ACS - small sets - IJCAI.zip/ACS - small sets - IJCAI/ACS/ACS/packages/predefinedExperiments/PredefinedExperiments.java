package predefinedExperiments;

import inputOutput.Input;
import inputOutput.ValueDistribution;

public class PredefinedExperiments
{
	public void run()
	{	
		boolean readCoalitionValuesFromFile = false;
		
		if( readCoalitionValuesFromFile )
			generateAndWriteCoalitionValuesToFile();
		
		NumOfEvaluatedSplitsByDPAndIDPAndODP computeNumOfEvaluatedSplits = new NumOfEvaluatedSplitsByDPAndIDPAndODP();
		computeNumOfEvaluatedSplits.run();
		
		NumOfCSandSubspacesPrunedByIDP numOfCSandSubspacesPrunedByIDP = new NumOfCSandSubspacesPrunedByIDP();
		numOfCSandSubspacesPrunedByIDP.run();
		
		RunDPAndIDPAndODP runDPAndIDPAndODP = new RunDPAndIDPAndODP();
		runDPAndIDPAndODP.run( readCoalitionValuesFromFile );

		RunIPorODPIP runODPIP = new RunIPorODPIP(); // setting this to "true" means we are run ODP-IP. Setting it to "false" means we run IP 
		runODPIP.run( readCoalitionValuesFromFile, true );
		
		RunIPorODPIP runIP = new RunIPorODPIP(); // setting this to "true" means we are run ODP-IP. Setting it to "false" means we run IP 
		runIP.run( readCoalitionValuesFromFile, false );
	}
	
	public int getNumOfRunningTimes( int numOfAgents )
	{
		if( numOfAgents == 15 ) return(500);
		if( numOfAgents == 16 ) return(400);
		if( numOfAgents == 17 ) return(300);
		if( numOfAgents == 18 ) return(275);
		if( numOfAgents == 19 ) return(250);
		if( numOfAgents == 20 ) return(225);
		if( numOfAgents == 21 ) return(200);
		if( numOfAgents == 22 ) return(175);
		if( numOfAgents == 23 ) return(150);
		if( numOfAgents == 24 ) return(120);
		if( numOfAgents == 25 ) return(100);
		if( numOfAgents == 26 ) return(50);
		if( numOfAgents == 27 ) return(20);
		return(1);
	}
	
	public void generateAndWriteCoalitionValuesToFile()
	{
		Input input = new Input();
		input.folderInWhichCoalitionValuesAreStored = "D:/CSGdata/coalitionValues";
		
		int minNumOfAgents = 15; int maxNumOfAgents = 27;
		
		ValueDistribution[] valueDistributions = { ValueDistribution.UNIFORM, ValueDistribution.NORMAL, ValueDistribution.NDCS, ValueDistribution.EXPONENTIAL, ValueDistribution.BETA,
				ValueDistribution.GAMMA, ValueDistribution.MODIFIEDUNIFORM, ValueDistribution.MODIFIEDNORMAL, ValueDistribution.AGENTBASEDUNIFORM, ValueDistribution.AGENTBASEDNORMAL};
		
		for(int distributionID = 0; distributionID < valueDistributions.length; distributionID++)
		{
			input.valueDistribution = valueDistributions[ distributionID ];

			input.folderInWhichCoalitionValuesAreStored = "D:/CSGdata/coalitionValues";

			for(input.numOfAgents=minNumOfAgents; input.numOfAgents<=maxNumOfAgents; input.numOfAgents++)
			{
				int numOfRunningTimes = getNumOfRunningTimes( input.numOfAgents );
				
				for(int problemID=1; problemID<=numOfRunningTimes; problemID++)
				{
					input.generateCoalitionValues();
					
					input.storeCoalitionValuesInFile( problemID );
				}
			}
		}
	}
}