package acsSolver;

import mainSolver.Result;
import inputOutput.*;
import ipSolver.IPSolver;
import ipSolver.IntegerPartitionGraph;
import ipSolver.MethodsForScanningTheInput;
import ipSolver.Subspace;

import java.util.Arrays;
import java.util.Random;

import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.BetaDistributionImpl;
import org.apache.commons.math.distribution.ExponentialDistributionImpl;

import general.Combinations;
import general.General;
import general.SubsetEnumerator;

public class ACS {
	int[] t;
    
    private boolean stop = false;
    
    private Input input;
    
    private Result result;
    
    int numOfCS;
    
    double[][]	skills;
    
    double[] agentStrength_normal;
	double[] agentStrength_uniform;
	
    public ACS( Input input, Result result ){
    	
    	random = new Random(0);
    	this.input = input;
    	this.result = result;
    	numOfCS = 0;
    	
    	agentStrength_normal  = new double[2];
		agentStrength_uniform = new double[2];
		for( int agent=1; agent<=2; agent++){
			agentStrength_normal [agent-1] = Math.max( 0, General.getRandomNumberFromNormalDistribution( 10,sigma,random) );
			agentStrength_uniform[agent-1] = random.nextDouble() * 10;
		}
    	
    	if(input.valueDistribution == ValueDistribution.BETA) {
    		long	_rndSeed = 0;
    		Random rnd = new Random(_rndSeed);

    		skills = new double[input.numOfAgents][4];
    		for (int i = 0; i < skills.length; ++i) {
    			for (int j = 0; j < skills[i].length; ++j) {
    				skills[i][j] = 10 * rnd.nextDouble();
    			}
    		}
    	}
    }
    
	int nbPermutations;
	int[] bestCoalitionStructure;
	double bestValue;
    public void runACS()
    {
    	int numOfAgents = input.numOfAgents;
    	set_f(0,0);

    	long[] requiredTimeForEachSize = new long[ numOfAgents+1 ];
    	requiredTimeForEachSize[1] = 0;
    	long[] startTimeForEachSize = new long[ numOfAgents+1 ];
    	int bestHalfOfGrandCoalition=-1;
        long startTime = System.currentTimeMillis();
        result.set_dpMaxSizeThatWasComputedSoFar(1);

        int numOfAgents2 = numOfAgents/2 /*+ numOfAgents%2*/;
        
        result.dpTimeForEachSize = requiredTimeForEachSize;
        bestValue = -1;
		bestCoalitionStructure = new int[1];
		bestCoalitionStructure[0] = (int) 1;
        if(true){
            
    		
        	int listeNoeudsOublies[][] = null;
        	int nbNoeudsOublies = 0;
        	
        	int nbAgents2=numOfAgents;
        	int iteration2=1;
    		if(numOfAgents <= 50) {
    			System.out.println("a");
        		IPSolver ipSolver = new IPSolver();
            	double[] avgValueForEachSize = new double[numOfAgents];
        		//Subspace[][] subspaces = ipSolver.initSubspaces(avgValueForEachSize,input);
        		
            	int nbNoeuds = 0;
            	for (int level = 1; level < 6; level++) {
    				//for (int j = 0; j < subspaces[level].length; j++) {
    				//	nbNoeuds++;
    				//}
            	}
            	
            	listeNoeudsOublies = new int[nbNoeuds][];
            	nbNoeudsOublies = 0;
            	for (int level = 1; level < (6); level++) {
    				//for (int j = 0; j < subspaces[level].length; j++) {
    				//	listeNoeudsOublies[nbNoeudsOublies] = subspaces[level][j].integersSortedAscendingly;
    				//	nbNoeudsOublies++;
    				//}
            	}
        	}
    		else {
    			if(numOfAgents <= 90) {
    				System.out.println("b");
    				EDP.Noeud tete2 = new EDP.Noeud(0,nbAgents2);
            		tete2.coalitions[0]=new EDP.Coalition(nbAgents2);
            		EDP.Filee file2 = new EDP.Filee(tete2);
            		EDP.Filee queue2 = file2;
            		
            		EDP.Filee fils2 = null;
            		fils2 = file2.tete.getFilsRacine();
            		if(fils2!=null){
            			queue2.suivant=fils2;
            			queue2=file2.tete.getQueue();
            		}
            		file2=file2.suivant;
            		iteration2++;
            		
            		while(file2!=null){
            			fils2 = file2.tete.getFils100();
            			if(fils2!=null){
            				queue2.suivant=fils2;
            				queue2=file2.tete.getQueue();
            			}
            			file2=file2.suivant;
            			iteration2++;
            		}
            		listeNoeudsOublies = EDP.Noeud.listeCoalitionsInt;
            		nbNoeudsOublies = EDP.Noeud.nbCoalitionsDiff;
    			}
    			else if(numOfAgents < 260) {
    				System.out.println("c");
    				EDP.Noeud tete2 = new EDP.Noeud(0,nbAgents2);
            		tete2.coalitions[0]=new EDP.Coalition(nbAgents2);
            		EDP.Filee file2 = new EDP.Filee(tete2);
            		EDP.Filee queue2 = file2;
            		
            		EDP.Filee fils2 = null;
            		fils2 = file2.tete.getFilsRacine();
            		if(fils2!=null){
            			queue2.suivant=fils2;
            			queue2=file2.tete.getQueue();
            		}
            		file2=file2.suivant;
            		iteration2++;
            		
            		while(file2!=null){
            			fils2 = file2.tete.getFils500();
            			if(fils2!=null){
            				queue2.suivant=fils2;
            				queue2=file2.tete.getQueue();
            			}
            			file2=file2.suivant;
            			iteration2++;
            		}
            		listeNoeudsOublies = EDP.Noeud.listeCoalitionsInt;
            		nbNoeudsOublies = EDP.Noeud.nbCoalitionsDiff;
    			}
    			else {
    				System.out.println("d");
    				EDP.Noeud tete2 = new EDP.Noeud(0,nbAgents2);
            		tete2.coalitions[0]=new EDP.Coalition(nbAgents2);
            		EDP.Filee file2 = new EDP.Filee(tete2);
            		EDP.Filee queue2 = file2;
            		
            		EDP.Filee fils2 = null;
            		fils2 = file2.tete.getFilsRacine();
            		if(fils2!=null){
            			queue2.suivant=fils2;
            			queue2=file2.tete.getQueue();
            		}
            		file2=file2.suivant;
            		iteration2++;
            		
            		while(file2!=null){
            			fils2 = file2.tete.getFils1000();
            			if(fils2!=null){
            				queue2.suivant=fils2;
            				queue2=file2.tete.getQueue();
            			}
            			file2=file2.suivant;
            			iteration2++;
            		}
            		listeNoeudsOublies = EDP.Noeud.listeCoalitionsInt;
            		nbNoeudsOublies = EDP.Noeud.nbCoalitionsDiff;
    			}
    		}
    		
    		
    		startTime = System.currentTimeMillis();
    		
    		
    		
    		int niveau=2, iParcours=0;
    		int nbAgentsMoitie = nbAgents2;
    		bestValue = -1;
    		bestCoalitionStructure = new int[1];
    		bestCoalitionStructure[0] = (int) (Math.pow(2, numOfAgents)-1);
    		
    		Thread th = new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					System.out.println("best CS part 2: "+Arrays.toString(ACS.this.bestCoalitionStructure));
			        System.out.println("best value: " + ACS.this.bestValue);
			        System.out.println("initial value: " + getSingletonCSValue());
					try {
						Thread.sleep(27000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("best CS part 2: "+Arrays.toString(ACS.this.bestCoalitionStructure));
			        System.out.println("best value: " + ACS.this.bestValue);
			        System.out.println("initial value: " + getSingletonCSValue());
				}
			});
    		th.start();
    		
    		System.out.println(nbNoeudsOublies);
    		while(niveau < 6 && iParcours< nbNoeudsOublies){
    			if(niveau<6) {
    				System.out.println(niveau);
        			if(listeNoeudsOublies[iParcours].length==niveau){
        				int[] tabPermute = new int[niveau];
        				for(int i=0; i<niveau; i++){
        					tabPermute[i]=i;
        				}
        				
        				int fact = 1;
        			    for (int i = 2; i <= niveau; i++) {
        			        fact = fact * i;
        			    }
        			    
        				int nLigne=0;
        				int allPossibilities[][] = new int[fact][niveau];
        				int inter;
        				FileePermute tetePermute=new FileePermute(new int[3],4);//il sera enlv� de toutes facons
        				FileePermute queuePermute=tetePermute;
        				for(int i=0; i< tabPermute.length; i++){
        					int[] tab2=new int[tabPermute.length];
        					for(int j=0; j<tabPermute.length; j++){
        						tab2[j]=tabPermute[j];
        					}
        					inter= tab2[0];
        					tab2[0]=tab2[i];
        					tab2[i]=inter;
        					queuePermute.suivant=new FileePermute(tab2, 1);
        					queuePermute=queuePermute.suivant;
        				}
        				tetePermute=tetePermute.suivant;
        				int nbComb=0;
        				while(tetePermute!=null){
        					FileePermute tete2Permute=tetePermute.suivant;
        					if(tetePermute.ind==tabPermute.length-1){
        						allPossibilities[nLigne]=tetePermute.tete;
        						nLigne++;
        						nbComb++;
        					}
        					else{
        						for(int i=tetePermute.ind; i< tabPermute.length; i++){
        							int[] tab2=new int[tabPermute.length];
        							for(int j=0; j<tabPermute.length; j++){
        								tab2[j]=tetePermute.tete[j];
        							}
        							inter= tab2[tetePermute.ind];
        							tab2[tetePermute.ind]=tab2[i];
        							tab2[i]=inter;
        							FileePermute newTetePermute = new FileePermute(tab2, tetePermute.ind+1);
        							newTetePermute.suivant=tete2Permute;
        							tete2Permute=newTetePermute;
        							
        						}
        						
        					}
        					tetePermute=tete2Permute;
        				}
        				for(int i=iParcours; i< nbNoeudsOublies; i++){
        					if(listeNoeudsOublies[i].length==niveau){
        						iParcours++;
        						
        						int allPossibilitiesGroups[][] = new int[fact][nbAgents2];
        						for(int l=0; l<nLigne; l++){
        							int m=0;
        							for(int j=0; j<allPossibilities[l].length; j++){
        								for(int k=0; k<listeNoeudsOublies[i][allPossibilities[l][j]]; k++){
        									allPossibilitiesGroups[l][m]=allPossibilities[l][j];
        									m++;
        								}
        							}
        						}
        						for(int n=0; n<nLigne; n++){
        							for(int j=0; j<nbAgents2; j++){
        								for(int k=j+1; k<nbAgents2; k++){
        									int tab2[] = new int[nbAgents2];
        									for(int l=0; l<nbAgents2; l++) {
        										tab2[l] = allPossibilitiesGroups[n][l];
        									}
        									if(tab2[k]!=tab2[j]){
        										int interm = tab2[k];
        										tab2[k] = tab2[j];
        										tab2[j] = interm;
        										int adresse[]= new int[niveau];
        										numOfCS++;
        										for(int l=0; l<tab2.length; l++){
        											adresse[tab2[l]]+= 1;
        										}
        										double curValue = -1;
        										for(int l=0; l<adresse.length; l++){
        											curValue+= getCoalitionValue(adresse[l],tab2,l);
        										}
        										if(bestValue <= curValue){
        											bestValue = curValue;
        											bestCoalitionStructure = new int[adresse.length];
        											for(int l=0; l<adresse.length; l++){
        												bestCoalitionStructure[l] = adresse[l];
        											}
        										}
        									}
        									
        								}
        							}
        							
        						}
        					}
        					else{
        						break;
        					}
        				}
        			}
        			niveau++;
        			
        		
    			}
    			else {

        			if(listeNoeudsOublies[iParcours].length==niveau){
        				int[] tabPermute = new int[niveau];
        				
        				for(int i=0; i<niveau; i++){
        					tabPermute[i]=i;
        				}
        				
        				int nLigne=2;
        				int allPossibilities[][] = new int[2][niveau];
        				for(int i=0; i<niveau; i++) {
        					allPossibilities[0][i] = i;
        					allPossibilities[1][i] = niveau-1-i;
        				}
        				System.out.println(nbNoeudsOublies);
        				for(int i=iParcours; i< nbNoeudsOublies; i++){
        					if(listeNoeudsOublies[i].length==niveau){
        						iParcours++;
        						
        						int allPossibilitiesGroups[][] = new int[2][nbAgents2];
        						
        						for(int l=0; l<nLigne; l++){
        							int m=0;
        							for(int j=0; j<allPossibilities[l].length; j++){
        								for(int k=0; k<listeNoeudsOublies[i][allPossibilities[l][j]]; k++){
        									allPossibilitiesGroups[l][m]=allPossibilities[l][j];
        									m++;
        								}
        							}
        						}
        						for(int n=0; n<nLigne; n++){
        							for(int j=0; j<nbAgents2; j++){
        								for(int k=j+1; k<nbAgents2; k++){
        									int tab2[] = new int[nbAgents2];
        									for(int l=0; l<nbAgents2; l++) {
        										tab2[l] = allPossibilitiesGroups[n][l];
        									}
        									
        									if(tab2[k]!=tab2[j]){
        										int interm = tab2[k];
        										tab2[k] = tab2[j];
        										tab2[j] = interm;
        										int adresse[]= new int[niveau];
        										numOfCS++;
        										for(int l=0; l<tab2.length; l++){
        											adresse[tab2[l]]+= 1;
        										}
        										double curValue = -1;
        										for(int l=0; l<adresse.length; l++){
        											curValue+= getCoalitionValue(adresse[l],tab2,l);
        										}
        										if(bestValue <= curValue){
        											bestValue = curValue;
        											bestCoalitionStructure = new int[adresse.length];
        											for(int l=0; l<adresse.length; l++){
        												bestCoalitionStructure[l] = adresse[l];
        											}
        										}
        									}
        									
        								}
        							}
        							
        						}
           					}
        					else{
        						break;
        					}
        				}
        			}
        			niveau++;
        			
        		
    			}
    		}
            
        }
        
        System.out.println("numOfCS: " + numOfCS);
		result.dpTime = System.currentTimeMillis() - startTime;
        System.out.println("best CS part 2: "+Arrays.toString(bestCoalitionStructure));
        System.out.println("best value: " + bestValue);
        System.out.println("initial value: " + getSingletonCSValue());
        	result.updateDPSolution2( bestCoalitionStructure , bestValue );
            result.set_bestSolutionFoundByPart2();
        if( input.printDistributionOfThefTable )
        	printDistributionOfThefTable();
        
        if( input.printPercentageOf_v_equals_f )
        	printPercentageOf_v_equals_f();
    }
    
    Random random;
    private final double sigma = 0.1;
    
    public double getSingletonCSValue() {
    	if( input.valueDistribution == ValueDistribution.UNIFORM ) {
			double csValue = 0;
    		for (int i = 0; i < input.numOfAgents; i++) {
    			csValue += Math.round( (1 * random.nextDouble()) * 100000000 );
			}
    		return csValue;
    	}
			
		//Normal distribution
		if( input.valueDistribution == ValueDistribution.NORMAL ) {
			double csValue = 0;
			for (int i = 0; i < input.numOfAgents; i++) {
				double value = Math.max( 0, 1 * General.getRandomNumberFromNormalDistribution( 10,sigma,random) );
				csValue += Math.round( value * 100000000 );
			}
			return csValue;
		}
		//Modified Uniform distribution
		if( input.valueDistribution == ValueDistribution.MODIFIEDUNIFORM ) {
			double value = random.nextDouble()*10*1;
			int probability = random.nextInt(100);
			if(probability <=20) value += random.nextDouble() * 50;
			return Math.round( value * 100000000 );
		}
		//Modified Normal distribution
		if( input.valueDistribution == ValueDistribution.MODIFIEDNORMAL ){
			double value = Math.max( 0, 1 * General.getRandomNumberFromNormalDistribution( 10,sigma,random) );
			int probability = random.nextInt(100);
			//if(probability <=20) valuesOfCurSize[index] += r.nextDouble() * 50;
			if(probability <=20) value += General.getRandomNumberFromNormalDistribution( 25,sigma,random);
			return Math.round( value * 100000000 );
		}
		//Exponential distribution
		if( input.valueDistribution == ValueDistribution.EXPONENTIAL ){
			ExponentialDistributionImpl exponentialDistributionImpl = new ExponentialDistributionImpl(1); //the mean of an exponential distribution is 1/lambda.
			double csValue = 0.0;
			for (int i = 0; i < input.numOfAgents; i++) {
				boolean repeat = false;
				double value = 0.0;
				do{
					try { value = Math.max( 0, 1 * exponentialDistributionImpl.sample() );
					} catch (MathException e) { repeat = true; }
				}while( repeat == true );
				csValue += value;
			}
			return csValue;
		}
		//Agent-based Normal distribution
		if( input.valueDistribution == ValueDistribution.AGENTBASEDNORMAL ) {
			double csValue;
			int[] members = new int[input.numOfAgents];
			int member = 0;
			for (int i = 0; i < input.numOfAgents; i++) {
					if(i>input.numOfAgents/2)
						members[member] = (1);
					else
						members[member] = (2);
					member++;
				
			}
			double value = 0.0;
			for( int m=0; m<input.numOfAgents; m++){
				double newValue;
				newValue = General.getRandomNumberFromNormalDistribution(agentStrength_normal[members[m]-1], sigma, random);
				value += Math.max( 0, newValue );
			}
			value = Math.round( value * 100000000 );	
			return value;
		}
		//Beta distribution
		if( input.valueDistribution == ValueDistribution.BETA ){
			BetaDistributionImpl betaDistributionImpl =new BetaDistributionImpl(0.5, 0.5);
			boolean repeat = false;
			double value = 0.0;
			do{
				try { value = Math.max( 0, 1 * betaDistributionImpl.sample() );
				} catch (MathException e) { repeat = true; }
			}while( repeat == true );
			return Math.round( value * 100000000 );				
		}
		
		if( input.valueDistribution == ValueDistribution.DISASTER_RESPONSE ) {
			//System.out.println("no");
			double csValue = 0.0;
			for (int t = 0; t < 4; ++t) {
				int r1 = t, r2 = t + 1;
				if (r2 == 4) {
					r2 = 0;
				}

				double x = 0.0;
//				for (int i : agents) {
//					x += _skills[i][r1] + _skills[i][r2];
//				}
				for (int i = 0; i < input.numOfAgents; ++i) {
					//if (cs[i] == ci) {
						x += skills[i][r1] + skills[i][r2];
					//}
				}

				csValue += x; //* rnd.nextDouble();
			}

			return csValue;
    	}
		
		return 0.0;
    }
    
    public double getCoalitionValue(int coalition, int[] cs, int ci) {
    	//random = new Random(0);
    	if( input.valueDistribution == ValueDistribution.UNIFORM )
			return Math.round( (coalition * random.nextDouble()) * 100000000 );

		//Normal distribution
		if( input.valueDistribution == ValueDistribution.NORMAL ) {
				double value = Math.max( 0, coalition * General.getRandomNumberFromNormalDistribution( 10,sigma,random) );
				return Math.round( value * 100000000 );
		}
		//Modified Uniform distribution
		if( input.valueDistribution == ValueDistribution.MODIFIEDUNIFORM ) {
			double value = random.nextDouble()*10*coalition;
			int probability = random.nextInt(100);
			if(probability <=20) value += random.nextDouble() * 50;
			//return Math.round( value * 100000000 );
			return value;
		}
		//Modified Normal distribution
		if( input.valueDistribution == ValueDistribution.MODIFIEDNORMAL ){
			double value = Math.max( 0, coalition * General.getRandomNumberFromNormalDistribution( 10,sigma,random) );
			int probability = random.nextInt(100);
			//if(probability <=20) valuesOfCurSize[index] += r.nextDouble() * 50;
			if(probability <=20) value += General.getRandomNumberFromNormalDistribution( 25,sigma,random);
			return Math.round( value * 100000000 );
		}
		//Exponential distribution
		if( input.valueDistribution == ValueDistribution.EXPONENTIAL ){
			ExponentialDistributionImpl exponentialDistributionImpl = new ExponentialDistributionImpl(1); //the mean of an exponential distribution is 1/lambda.
			boolean repeat = false;
			double value = 0.0;
			do{
				try { value = Math.max( 0, coalition * exponentialDistributionImpl.sample() );
				} catch (MathException e) { repeat = true; }
			}while( repeat == true );
			return value;
		}
		//Agent-based Uniform distribution
		if( input.valueDistribution == ValueDistribution.AGENTBASEDUNIFORM ) {
			//for(int coalition = coalitionValues.length-1; coalition>0; coalition--){
			int[] members = new int[coalition];
			int member = 0;
			for (int i = 0; i < cs.length; i++) {
				if (cs[i] == ci) {
					if(i>input.numOfAgents/2)
						members[member] = (1);
					else
						members[member] = (2);
					member++;
				}
				
			}
			
			//if percentage is, say 60%, then an agent's value can go up by at most 60%, and down by at most 60%
			double percentage = 100;
			double value = 0.0;
			for( int m=0; m<coalition; m++){
				//System.out.println("ddd "+members[m]);
				//System.out.println("ddd "+agentStrength_uniform[members[m]-1]);
				double rangeSize = (percentage/(double)100) * agentStrength_uniform[members[m]-1] * 2;
				double startOfRange = ((100 - percentage)/(double)100) * agentStrength_uniform[members[m]-1];
				value += startOfRange + (random.nextDouble()*rangeSize);
			}
			value = Math.round( value * 100000000 );
			return value;
		}		
		//Agent-based Normal distribution
		if( input.valueDistribution == ValueDistribution.AGENTBASEDNORMAL ) {
			int[] members = new int[coalition];
			int member = 0;
			for (int i = 0; i < cs.length; i++) {
				if (cs[i] == ci) {
					if(i>input.numOfAgents/2)
						members[member] = (1);
					else
						members[member] = (2);
					member++;
				}
				
			}
			double value = 0.0;
			for( int m=0; m<coalition; m++){
				double newValue;
				newValue = General.getRandomNumberFromNormalDistribution(agentStrength_normal[members[m]-1], sigma, random);
				value += Math.max( 0, newValue );
			}
			value = Math.round( value * 100000000 );	
			return value;
		}
		//NDCS distribution
		if( input.valueDistribution == ValueDistribution.NDCS ) {
			double value = 0.0;	
			do{ 
				value = (General.getRandomNumberFromNormalDistribution(coalition,Math.sqrt(coalition),random));
			}while( value <= 0 );
			value = Math.round( value * 100000000 );	
			return value;
		}

		//Beta distribution
		if( input.valueDistribution == ValueDistribution.BETA ){
			BetaDistributionImpl betaDistributionImpl =new BetaDistributionImpl(0.5, 0.5);
			boolean repeat = false;
			double value = 0.0;
			do{
				try { value = Math.max( 0, coalition * betaDistributionImpl.sample() );
				} catch (MathException e) { repeat = true; }
			}while( repeat == true );
			return Math.round( value * 100000000 );				
		}
		//disaster response
		if( input.valueDistribution == ValueDistribution.DISASTER_RESPONSE ) {
			//System.out.println("no");
			double csValue = 0.0;
			for (int t = 0; t < 4; ++t) {
				int r1 = t, r2 = t + 1;
				if (r2 == 4) {
					r2 = 0;
				}

				double x = 0.0;
//				for (int i : agents) {
//					x += _skills[i][r1] + _skills[i][r2];
//				}
				for (int i = 0; i < input.numOfAgents; ++i) {
					if (cs[i] == ci) {
						x += skills[i][r1] + skills[i][r2];
					}
				}

				csValue += x; //* rnd.nextDouble();
			}

			return csValue;
    	}
		
		return 0.0;
		
    }
	
    private int[][] getPermutations(int niveau){
    	int moitieNiveau=niveau/2, moitieNiveau2=moitieNiveau+1;
    	nbPermutations=0;
		int tabPossibilites[][];
		int tabPermutations[][] = null;
		if(niveau%2==0){
			tabPossibilites = new int[1][niveau];
			for(int i=0; i<moitieNiveau; i++){
				tabPossibilites[0][i]=0;
			}
			for(int i=moitieNiveau; i<niveau; i++){
				tabPossibilites[0][i]=1;
			}
			tabPermutations= new int[niveau*niveau][niveau];
			for(int i=0; i<niveau; i++){
				tabPermutations[0][i] = tabPossibilites[0][i];
			}
			
			nbPermutations++;
			for(int i=0; i< moitieNiveau; i++){
				for(int j=moitieNiveau; j<niveau; j++){
					int newTabPossibilites[][] = new int[1][niveau];
					for(int k=0; k<niveau; k++){
						newTabPossibilites[0][k] = tabPossibilites[0][k];
					}
					int interm = newTabPossibilites[0][i];
					newTabPossibilites[0][i] = newTabPossibilites[0][j];
					newTabPossibilites[0][j] = interm;
					tabPermutations[nbPermutations] = newTabPossibilites[0];
					nbPermutations++;
					
					
				}
				
			}
			for(int i=0; i<moitieNiveau2; i++){
				tabPermutations[nbPermutations][i]=1;
			}
			for(int i=moitieNiveau2; i<niveau; i++){
				tabPermutations[nbPermutations][i]=0;
			}
			nbPermutations++;
		}
		else{
			tabPossibilites = new int[2][niveau];
			for(int i=0; i<moitieNiveau; i++){
				tabPossibilites[0][i]=0;
			}
			for(int i=moitieNiveau; i<niveau; i++){
				tabPossibilites[0][i]=1;
			}
			
			for(int i=0; i<moitieNiveau2; i++){
				tabPossibilites[1][i]=1;
			}
			for(int i=moitieNiveau2; i<niveau; i++){
				tabPossibilites[1][i]=0;
			}
			
			tabPermutations= new int[niveau*niveau][niveau];
			for(int i=0; i<niveau; i++){
				tabPermutations[0][i] = tabPossibilites[0][i];
			}
			
			nbPermutations++;
			for(int i=0; i< moitieNiveau; i++){
				for(int j=moitieNiveau; j<niveau; j++){
					int newTabPossibilites[][] = new int[1][niveau];
					for(int k=0; k<niveau; k++){
						newTabPossibilites[0][k] = tabPossibilites[0][k];
					}
					int interm = newTabPossibilites[0][i];
					newTabPossibilites[0][i] = newTabPossibilites[0][j];
					newTabPossibilites[0][j] = interm;
					tabPermutations[nbPermutations] = newTabPossibilites[0];
					nbPermutations++;
					
					
				}
				
			}
			for(int i=0; i<moitieNiveau2; i++){
				tabPermutations[nbPermutations][i]=1;
			}
			for(int i=moitieNiveau2; i<niveau; i++){
				tabPermutations[nbPermutations][i]=0;
			}
			nbPermutations++;
			
			for(int i=0; i< moitieNiveau2; i++){
				for(int j=moitieNiveau2; j<niveau; j++){
					int newTabPossibilites[][] = new int[1][niveau];
					for(int k=0; k<niveau; k++){
						newTabPossibilites[0][k] = tabPossibilites[1][k];
					}
					int interm = newTabPossibilites[0][i];
					newTabPossibilites[0][i] = newTabPossibilites[0][j];
					newTabPossibilites[0][j] = interm;
					tabPermutations[nbPermutations] = newTabPossibilites[0];
					nbPermutations++;
					
					
				}
				
			}
			
		}
		return tabPermutations;
    }
    
    private void evaluateSplitsOfSecondPart(int coalitionInBitFormat, int[] binaryCoalition, int[][] tabPermutations) {
    	double curValue=-1;
    	double bestValue=-1;
    	int bestHalfOfCoalitionInBitFormat=-1;
    	bestValue=input.getCoalitionValue(coalitionInBitFormat);
    	
		for(int i=0; i<nbPermutations; i++){
			int numAgent=0;
			int firstHalfInBitFormat=0, secondHalfInBitFormat=0;
			for(int j=0; j<binaryCoalition.length; j++){
				if(binaryCoalition[j]==1){
					if(tabPermutations[i][numAgent]==0){
						firstHalfInBitFormat += 1<< j;
					}
					else{
						secondHalfInBitFormat += 1<<j;
					}
					numAgent++;
				}
			}
			curValue = get_f( firstHalfInBitFormat ) + get_f( secondHalfInBitFormat );
			if(bestValue<=curValue)
    		{
    			bestValue = curValue;
    			if( input.solverName == SolverNames.DP ){ //i.e., if we are using the t table
    				if( Integer.bitCount(firstHalfInBitFormat) > Integer.bitCount(secondHalfInBitFormat) )
    					bestHalfOfCoalitionInBitFormat = firstHalfInBitFormat;
    				else
    					bestHalfOfCoalitionInBitFormat = secondHalfInBitFormat;
    			}
    		}
		}
		set_f( coalitionInBitFormat, bestValue );
    	if( input.solverName == SolverNames.DP )
    		t[ coalitionInBitFormat ] = bestHalfOfCoalitionInBitFormat;
		
		
    }
    
    private long[] computeNumOfPossibleSplitsBasedOnSizeOfFirstHalf( int size )
    {
    	long[] numOfPossibleSplitsBasedOnSizeOfFirstHalf = new long[size];
    	for(int sizeOfFirstHalf=(int)Math.ceil(size/(double)2); sizeOfFirstHalf<size; sizeOfFirstHalf++){
    		int sizeOfSecondHalf = (int)(size - sizeOfFirstHalf);
    		if(( (size % 2) == 0 )&&( sizeOfFirstHalf == sizeOfSecondHalf ))
    			numOfPossibleSplitsBasedOnSizeOfFirstHalf[ sizeOfFirstHalf ] = Combinations.binomialCoefficient(size, sizeOfFirstHalf )/2;
    		else
    			numOfPossibleSplitsBasedOnSizeOfFirstHalf[ sizeOfFirstHalf ] = Combinations.binomialCoefficient(size, sizeOfFirstHalf );    		
    	}
    	return( numOfPossibleSplitsBasedOnSizeOfFirstHalf );
    }    
    
    private int[] getOptimalSplit( int coalitionInBitFormat, int bestHalfOfCoalition )
    {
    	int[] optimalSplit;
    	if( bestHalfOfCoalition == coalitionInBitFormat )
    	{
    		optimalSplit = new int[1];
    		optimalSplit[0] = coalitionInBitFormat;
    	}
    	else
    	{
    		int[] arrayOfBestHalf = new int[2];
			int[][] arrayOfOptimalSplit = new int[2][];
    		int[] arrayOfCoalitionInBitFormat = new int[2]; 

    		arrayOfCoalitionInBitFormat[0] = bestHalfOfCoalition;
    		arrayOfCoalitionInBitFormat[1] = coalitionInBitFormat - bestHalfOfCoalition;
    		for( int i=0; i<2; i++ )
    		{
    			if( (input.solverName == SolverNames.DP) ) 
    				arrayOfBestHalf[i] = t[ arrayOfCoalitionInBitFormat[i] ];
    			else
    				arrayOfBestHalf[i] = getBestHalf( arrayOfCoalitionInBitFormat[i] );
    			
    			arrayOfOptimalSplit[i] = getOptimalSplit( arrayOfCoalitionInBitFormat[i], arrayOfBestHalf[i] );
    		}
        	optimalSplit = new int[ arrayOfOptimalSplit[0].length + arrayOfOptimalSplit[1].length ];
        	int k=0;
        	for( int i=0; i<2; i++ )
        		for( int j=0; j<arrayOfOptimalSplit[i].length; j++ )
        		{
        			optimalSplit[k] = arrayOfOptimalSplit[i][j];
        			k++;
        		}
    	}
    	return( optimalSplit );
    }
    
    public int[][] getOptimalSplit( int[][] CS )
    {   
    	int[][] optimalSplit = new int[ CS.length ][]; 
    	int numOfCoalitionsInFinalResult=0;
    	
    	for( int i=0; i<CS.length; i++ )
    	{
   			int coalitionInBitFormat = Combinations.convertCombinationFromByteToBitFormat( CS[i] );
   			int bestHalfOfCoalitionInBitFormat = getBestHalf( coalitionInBitFormat );
   			optimalSplit[i] = getOptimalSplit( coalitionInBitFormat, bestHalfOfCoalitionInBitFormat );
    		numOfCoalitionsInFinalResult += optimalSplit[i].length;
    	}
    	int[][] finalResult = new int[ numOfCoalitionsInFinalResult ][];
    	int k=0;
    	for( int i=0; i<CS.length; i++ )
    	{
    		for( int j=0; j<optimalSplit[i].length; j++ )
    		{
    			finalResult[k] = Combinations.convertCombinationFromBitToByteFormat( optimalSplit[i][j] , input.numOfAgents );
    			k++;
    		}
    	}
    	return( finalResult );
    }
    
    private int evaluateSplitsOfGrandCoalition()
    {    	
    	double curValue=-1;
    	double bestValue=-1;
    	int bestHalfOfGrandCoalitionInBitFormat=-1;
    	int numOfCoalitions = 1 << input.numOfAgents;
    	int grandCoalition = (1 << input.numOfAgents) - 1;

    	for (int firstHalfOfGrandCoalition=(numOfCoalitions/2)-1; firstHalfOfGrandCoalition<numOfCoalitions; firstHalfOfGrandCoalition++)
    	{
    		int secondHalfOfGrandCoalition = numOfCoalitions-1-firstHalfOfGrandCoalition;
    		curValue = get_f(firstHalfOfGrandCoalition) + get_f(secondHalfOfGrandCoalition); 
    		if( curValue > bestValue )
    		{
    			bestValue = curValue;
    			bestHalfOfGrandCoalitionInBitFormat = firstHalfOfGrandCoalition;
    		}
    	}    	
    	int firstHalfOfGrandCoalition = grandCoalition;
    	curValue = get_f( firstHalfOfGrandCoalition );
		if( curValue > bestValue )
		{
			bestValue = curValue;
			bestHalfOfGrandCoalitionInBitFormat = firstHalfOfGrandCoalition;
		}    	
    	set_f( grandCoalition, bestValue);
		if( input.solverName == SolverNames.DP ) //Then use the t table
        	t[ grandCoalition ] = bestHalfOfGrandCoalitionInBitFormat;
		
    	return( bestHalfOfGrandCoalitionInBitFormat );
    }
    
    private void evaluateSplits( int[] coalitionInByteFormat, int coalitionSize, long[] numOfPossibleSplitsBasedOnSizeOfFirstHalf )
    {
    	double curValue=-1;
    	double bestValue=-1;
    	int bestHalfOfCoalitionInBitFormat=-1;
    	int numOfAgents = input.numOfAgents;
    	int coalitionInBitFormat = Combinations.convertCombinationFromByteToBitFormat( coalitionInByteFormat );

    	int[] bit = new int[numOfAgents+1];
		for(int i=0; i<numOfAgents; i++)
			bit[i+1] = 1 << i;
		
    	for(int sizeOfFirstHalf=(int)Math.ceil(coalitionSize/(double)2); sizeOfFirstHalf<coalitionSize; sizeOfFirstHalf++)
    	{
    		if(( (input.solverName == SolverNames.IDP)||(input.solverName == SolverNames.ODPIP) )&&( sizeOfFirstHalf > numOfAgents-coalitionSize )
    				&&( coalitionSize!=numOfAgents )) continue;
    		
        	int[] indicesOfMembersOfFirstHalf = new int[ sizeOfFirstHalf ];
    		for(int i=0; i<sizeOfFirstHalf; i++)
    			indicesOfMembersOfFirstHalf[i] = (int)(i+1);

    		int firstHalfInBitFormat=0;
        	for(int i=0; i<sizeOfFirstHalf; i++)
        		firstHalfInBitFormat += bit[ coalitionInByteFormat[ indicesOfMembersOfFirstHalf[i]-1 ] ];
        	
        	int secondHalfInBitFormat = (coalitionInBitFormat-firstHalfInBitFormat);        	
        	
        	curValue = get_f( firstHalfInBitFormat ) + get_f( secondHalfInBitFormat );
            if( bestValue < curValue ){
                bestValue = curValue;
                if( input.solverName == SolverNames.DP )
                	bestHalfOfCoalitionInBitFormat = firstHalfInBitFormat;
            }            
        	for(int j=1; j<numOfPossibleSplitsBasedOnSizeOfFirstHalf[ sizeOfFirstHalf ]; j++)
            {
            	/**/
    			Combinations.getPreviousCombination( coalitionSize, sizeOfFirstHalf, indicesOfMembersOfFirstHalf );
            	
            	firstHalfInBitFormat=0;
            	for(int i=0; i<sizeOfFirstHalf; i++)
            		firstHalfInBitFormat += bit[ coalitionInByteFormat[ indicesOfMembersOfFirstHalf[i]-1 ] ];
            	secondHalfInBitFormat = (coalitionInBitFormat-firstHalfInBitFormat);           	
            	
            	curValue = get_f( firstHalfInBitFormat ) + get_f( secondHalfInBitFormat );
            	if( bestValue < curValue ) {
            		bestValue = curValue;
            		if( input.solverName == SolverNames.DP )
            			bestHalfOfCoalitionInBitFormat = firstHalfInBitFormat;
            	}
            }            
    	}    	
        int firstHalfInBitFormat = coalitionInBitFormat;
		curValue = get_f( firstHalfInBitFormat );
        if( bestValue < curValue ){
            bestValue = curValue;
            if( input.solverName == SolverNames.DP )
            	bestHalfOfCoalitionInBitFormat = firstHalfInBitFormat;
        }    	

        if( input.solverName == SolverNames.ODPIP )
        	if( result.get_max_f( coalitionSize-1 ) < bestValue )
        		result.set_max_f( coalitionSize-1 ,   bestValue );
        
        set_f( coalitionInBitFormat, bestValue );
        if( input.solverName == SolverNames.DP )
        	t[ coalitionInBitFormat ] = bestHalfOfCoalitionInBitFormat;
    }
    
    private void evaluateSplitsEfficiently( int[] coalitionInByteFormat, int coalitionSize, int numOfPossibilities )
    {
    	double curValue=-1;
    	double bestValue=-1;
    	int bestHalfOfCoalitionInBitFormat=-1;
    	int coalitionInBitFormat = Combinations.convertCombinationFromByteToBitFormat( coalitionInByteFormat );
    	bestValue=input.getCoalitionValue(coalitionInBitFormat);
    	bestHalfOfCoalitionInBitFormat=coalitionInBitFormat;

    	for (int firstHalfInBitFormat = coalitionInBitFormat-1 & coalitionInBitFormat; /*firstHalfInBitFormat > 0*/; firstHalfInBitFormat = firstHalfInBitFormat-1 & coalitionInBitFormat)
    	{
    		int secondHalfInBitFormat = coalitionInBitFormat^firstHalfInBitFormat;
    		curValue = get_f( firstHalfInBitFormat ) + get_f( secondHalfInBitFormat );
    		if(bestValue<=curValue)
    		{
    			bestValue = curValue;
    			if( input.solverName == SolverNames.DP ){ //i.e., if we are using the t table
    				if( Integer.bitCount(firstHalfInBitFormat) > Integer.bitCount(secondHalfInBitFormat) )
    					bestHalfOfCoalitionInBitFormat = firstHalfInBitFormat;
    				else
    					bestHalfOfCoalitionInBitFormat = secondHalfInBitFormat;
    			}
    		}
    		if((firstHalfInBitFormat & (firstHalfInBitFormat-1))==0)break;
    	}
    	if( input.solverName == SolverNames.ODPIP )
    		if( result.get_max_f( coalitionSize-1 ) < bestValue )
    			result.set_max_f( coalitionSize-1 ,   bestValue );

    	set_f( coalitionInBitFormat, bestValue );
    	if( input.solverName == SolverNames.DP )
    		t[ coalitionInBitFormat ] = bestHalfOfCoalitionInBitFormat;
    }

    private void evaluateSplitsOptimally( int C, int sizeOfC, int grandCoalition, int numOfAgents )
    {
    	double bestValue=input.getCoalitionValue( C + 3 ); //curValue = v( C U {1,2} )
    	
    	int remainingAgents = grandCoalition - C - 3;
    	int minAgent =0; //here, I put "=0" just to stop the compiler from complaining 
    	for(int i=2; i<numOfAgents; i++)
			if ((remainingAgents & (1<<i)) != 0){ //If agent "i+1" is a member of "remainingAgents"
				minAgent = i+1;
				break;
			}
    	int acceptableMinAgents = (1 << (minAgent-1)) - 1;
    	
    	double value;
    	for (int C1 = C & C; /* C1>0 */; C1 = C1-1 & C)
    	{
    		int C2 = C-C1;

    		value = input.coalitionValues[ C1+1 ] + input.coalitionValues[ C2+2 ];
    		if( bestValue < value ) bestValue = value;

    		value = input.coalitionValues[ C1+2 ] + input.coalitionValues[  C2+1 ];
    		if( bestValue < value ) bestValue = value;

    		if( (C1 & acceptableMinAgents)!=0 ){
    			value = input.coalitionValues[ C1 ] + get_f( C2+3 );
    			if( bestValue < value ) bestValue = value;
    		}
    		if( (C2 & acceptableMinAgents)!=0 ){
    			value = input.coalitionValues[ C2 ] + get_f( C1+3 );
    			if( bestValue < value ) bestValue = value;
    		}
    		if((C1 & (C1-1))==0) break;
    	}
    	set_f( C + 3, bestValue );
    	
    	
    	if( input.solverName == SolverNames.ODPIP )
    		if( result.get_max_f( (sizeOfC+2)-1 ) < bestValue )
    			result.set_max_f( (sizeOfC+2)-1 ,   bestValue );
    }
    
    private void evaluateSplitsOf12()
    {
    	int coalitionSize = 2;
    	int coalitionInBitFormat = 3;
    	int firstHalfInBitFormat = 1;
    	int secondHalfInBitFormat = 2;    	
    	double valueOfCoalition = input.getCoalitionValue(coalitionInBitFormat);
    	double valueOfSplit = get_f( firstHalfInBitFormat ) + get_f( secondHalfInBitFormat );
    	double bestValue = Math.max( valueOfCoalition, valueOfSplit );
    	set_f( coalitionInBitFormat, bestValue );
        if( input.solverName == SolverNames.ODPIP )
       		result.set_max_f( coalitionSize-1, bestValue );
    }
    
    private int getBestHalf( int coalitionInBitFormat )
    {
    	double valueOfBestSplit = input.getCoalitionValue( coalitionInBitFormat );
    	int best_firstHalfInBitFormat = coalitionInBitFormat;
    	
        int[] bit = new int[input.numOfAgents+1];
		for(int i=0; i<input.numOfAgents; i++)
			bit[i+1] = 1 << i;
    	
    	int[] coalitionInByteFormat = Combinations.convertCombinationFromBitToByteFormat(coalitionInBitFormat, input.numOfAgents);
    	
    	int coalitionSize = (int)coalitionInByteFormat.length;
		for(int sizeOfFirstHalf=(int)Math.ceil(coalitionSize/(double)2); sizeOfFirstHalf<coalitionSize; sizeOfFirstHalf++)
    	{
    		int sizeOfSecondHalf = (int)(coalitionSize - sizeOfFirstHalf);

    		long numOfPossibleSplits;
    		if(( (coalitionSize % 2) == 0 )&&( sizeOfFirstHalf == sizeOfSecondHalf ))
    			numOfPossibleSplits = Combinations.binomialCoefficient(coalitionSize, sizeOfFirstHalf )/2;
    		else
				numOfPossibleSplits = Combinations.binomialCoefficient(coalitionSize, sizeOfFirstHalf );    		
    		
        	int[] indicesOfMembersOfFirstHalf = new int[ sizeOfFirstHalf ];
    		for(int i=0; i<sizeOfFirstHalf; i++)
    			indicesOfMembersOfFirstHalf[i] = (int)(i+1);

    		int firstHalfInBitFormat=0;
        	for(int i=0; i<sizeOfFirstHalf; i++)
        		firstHalfInBitFormat += bit[ coalitionInByteFormat[ indicesOfMembersOfFirstHalf[i]-1 ] ];

        	int secondHalfInBitFormat = (coalitionInBitFormat-firstHalfInBitFormat);
        	
        	if( get_f( firstHalfInBitFormat ) + get_f( secondHalfInBitFormat ) > valueOfBestSplit ){
            	best_firstHalfInBitFormat = firstHalfInBitFormat;
            	valueOfBestSplit = get_f( firstHalfInBitFormat ) + get_f( secondHalfInBitFormat );
        	}
        	for(int j=1; j<numOfPossibleSplits; j++)
            {
    			Combinations.getPreviousCombination( coalitionSize, sizeOfFirstHalf, indicesOfMembersOfFirstHalf );

            	firstHalfInBitFormat=0;
            	for(int i=0; i<sizeOfFirstHalf; i++)
            		firstHalfInBitFormat += bit[ coalitionInByteFormat[ indicesOfMembersOfFirstHalf[i]-1 ] ];

            	secondHalfInBitFormat = (coalitionInBitFormat-firstHalfInBitFormat);

            	if( get_f( firstHalfInBitFormat ) + get_f( secondHalfInBitFormat ) > valueOfBestSplit ){
                	best_firstHalfInBitFormat = firstHalfInBitFormat;
                	valueOfBestSplit = get_f( firstHalfInBitFormat ) + get_f( secondHalfInBitFormat );
            	}
            }
    	}
		return( best_firstHalfInBitFormat );	
    }
    
    private void printPercentageOf_v_equals_f()
    {
    	int numOfAgents = input.numOfAgents;
    	int totalNumOfCoalitions = 1 << numOfAgents;
    	int totalCounter=0;
    	long[] numOfCoalitionsOfParticularSize = new long[numOfAgents+1];
    	int[] counter = new int[numOfAgents+1];
    	for(int i=1; i<numOfAgents+1; i++){
    		counter[i]=0;
    		numOfCoalitionsOfParticularSize[i] = Combinations.binomialCoefficient(numOfAgents, i);
    	}
    	for(int i=1; i<totalNumOfCoalitions; i++)
    		if(input.getCoalitionValue(i)==get_f(i)){
    			counter[ Integer.bitCount(i) ]++;
    			totalCounter++;
    		}
    	System.out.println("percentage of all coalitions of that are optimal partitions of themselves is: "+((double)totalCounter/totalNumOfCoalitions));
    	for(int i=2; i<=numOfAgents; i++){
    		System.out.println("size: "+i+"  percentage: "+((double)counter[i]/numOfCoalitionsOfParticularSize[i]));
    		
    	}
    }
    
//*********************************************************************************************************
    
    public void set_f( int index, double value ){
    	if( input.solverName == SolverNames.ODPIP )
    		result.idpSolver_whenRunning_ODPIP.updateValueOfBestPartitionFound( index, value);
    }
    public double get_f( int index ){
    	return result.idpSolver_whenRunning_ODPIP.getValueOfBestPartitionFound( index );
    }
    
	public void setStop( boolean value )
	{
		stop = value;
	}
	public boolean getStop()
	{
		return stop;
	}
		
	public void runODP()
    {
		int n = input.numOfAgents;

    	set_f(0,0);

    	long[] requiredTimeForEachSize = new long[ n+1 ];
    	requiredTimeForEachSize[1] = 0;
    	long[] startTimeForEachSize = new long[ n+1 ];
    	int A = (1 << n) - 1;
    	int bestHalfOfGrandCoalition=-1;
        long startTime = System.currentTimeMillis();
        result.set_dpMaxSizeThatWasComputedSoFar(1);

        for (int s = 0; s <= n-2; s++)
        {        	
        	startTimeForEachSize[ s+2 ] = System.currentTimeMillis();
        	if( s == 0 ){
        		evaluateSplitsOf12();
        	}else{
        		if( s < n-2 ){
        			SubsetEnumerator subsetEnumerator = new SubsetEnumerator(n-2, s);
        			int C = subsetEnumerator.getFirstSubset() << 2;
        			int markThatListHasFinished = (1<<(n-2)) << 2;
        			while(C < markThatListHasFinished){
        				evaluateSplitsOptimally( C, s, A, n );
        				C = subsetEnumerator.getNextSubset() << 2;
        			}
        		}else{
        			bestHalfOfGrandCoalition = evaluateSplitsOfGrandCoalition();
        		}
        	}
        	if( s < n-2 ){
   				bestHalfOfGrandCoalition = evaluateSplitsOfGrandCoalition();
   				int[] bestCSFoundSoFar = getOptimalSplit( A, bestHalfOfGrandCoalition);
   				int[][] bestCSFoundSoFar_byteFormat = Combinations.convertSetOfCombinationsFromBitToByteFormat( bestCSFoundSoFar, n );
   				result.updateDPSolution( bestCSFoundSoFar_byteFormat , input.getCoalitionStructureValue( bestCSFoundSoFar_byteFormat ) );
   			}
    		requiredTimeForEachSize[ s+2 ] = System.currentTimeMillis() - startTimeForEachSize[ s+2 ];
    		System.out.print("    The time for ODP to finish evaluating the splittings of coalitions of size "+(s+2)+" is: "+requiredTimeForEachSize[s+2]);
    		System.out.println(".  The best CS found so far: "+General.convertArrayToString(result.get_dpBestCSFound())+" , its value is: "+result.get_dpValueOfBestCSFound());

   			result.set_dpMaxSizeThatWasComputedSoFar( s+2 );
        }        
        result.dpTimeForEachSize = requiredTimeForEachSize;

        int[] bestCSFound = getOptimalSplit( A, bestHalfOfGrandCoalition);
        
        result.dpTime = System.currentTimeMillis() - startTime;
        int[][] dpBestCSInByteFormat = Combinations.convertSetOfCombinationsFromBitToByteFormat( bestCSFound, n );
        result.updateDPSolution( dpBestCSInByteFormat , input.getCoalitionStructureValue( dpBestCSInByteFormat ) );
    }
    
	private void printDistributionOfThefTable()
	{
		int totalNumOfCoalitions = 1 << input.numOfAgents;
		int[] counter = new int[40];
		for(int i=0; i<counter.length; i++){
			counter[i]=0;
		}		
		long min = Integer.MAX_VALUE;
		long max = Integer.MIN_VALUE;
		for(int i=1; i<totalNumOfCoalitions; i++){
			long currentWeightedValue = (long)Math.round( get_f(i) / Integer.bitCount(i) );
			if( min > currentWeightedValue )
				min = currentWeightedValue ;
			if( max < currentWeightedValue )
				max = currentWeightedValue ;
		}
		System.out.println("The maximum weighted f value is  "+max+"  and the minimum one is  "+min);
		
		for(int i=1; i<totalNumOfCoalitions; i++){
			long currentWeightedValue = (long)Math.round( get_f(i) / Integer.bitCount(i) );
			int percentageOfMax = (int)Math.round( (currentWeightedValue-min) * (counter.length-1) / (max-min) );
			counter[percentageOfMax]++;
		}
		System.out.println("The distribution of the weighted coalition values:");
		System.out.print(ValueDistribution.toString(input.valueDistribution)+"_f = [");
		for(int i=0; i<counter.length; i++)
			System.out.print(counter[i]+" ");
		System.out.println("]");
	}
}