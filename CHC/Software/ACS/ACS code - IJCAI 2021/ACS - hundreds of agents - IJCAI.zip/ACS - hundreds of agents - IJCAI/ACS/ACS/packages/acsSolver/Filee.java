package acsSolver;

public class Filee {
	Noeud tete;
	Filee suivant;
	public Filee(Noeud tete){
		this.tete=tete;
		suivant=null;
	}
}
