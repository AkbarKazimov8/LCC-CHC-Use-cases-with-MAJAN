package mainSolver;

import acsSolver.*;
import general.Combinations;
import inputOutput.*;
import ipSolver.*;

public class MainSolver
{
	public Result solve( Input input )	
	{
		for( int problemID=1; problemID<=input.numOfRunningTimes; problemID++) //for every problem instance
		{			
			//System.out.println("solver0");
			input.problemID = (new Integer(problemID)).toString();
			//System.out.println("solver0.1");
			Result result = new Result(input);
			//System.out.println("solver0.2");
			Output output = new Output();
			//System.out.println("solver0.3");
			output.initOutput( input );
			//System.out.println("solver0.4");

			if ( (input.solverName == SolverNames.DP) || (input.solverName == SolverNames.IDP) ){
				DPSolver dpSolver = new DPSolver(input, result); dpSolver.runDPorIDP();
			}
			else if ( (input.solverName == SolverNames.ACS) ){
				System.out.println("solver1");
				ACS dpSolver = new ACS(input, result); dpSolver.runACS();
			}
			else if ( (input.solverName == SolverNames.ODP) ){
				DPSolver dpSolver = new DPSolver(input, result); dpSolver.runODP();
			}
			else if ( (input.solverName == SolverNames.IP) || (input.solverName == SolverNames.ODPIP) ){
				IPSolver ipSolver = new IPSolver(); ipSolver.solve( input, output, result );
			}
			if( input.numOfRunningTimes == 1 ) {
				return( result );
			}else{
				if( problemID < input.numOfRunningTimes ){
					if( input.readCoalitionValuesFromFile )
						input.readCoalitionValuesFromFile( problemID+1 );
					else
						input.generateCoalitionValues();
				}
				System.out.println(input.numOfAgents+" agents, "+ValueDistribution.toString(input.valueDistribution)+" distribution. The solver just finished solving "+input.problemID+" problems out of  "+input.numOfRunningTimes);
			}
		}
		return null;
	}
}