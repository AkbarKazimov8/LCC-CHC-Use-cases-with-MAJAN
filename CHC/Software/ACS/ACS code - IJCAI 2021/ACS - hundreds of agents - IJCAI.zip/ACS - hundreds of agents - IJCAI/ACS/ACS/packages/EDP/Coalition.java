package EDP;

public class Coalition {
	int nbElts;
	
	public Coalition(int nbElts){
		this.nbElts=nbElts;
		
	}
}
